/**
 * \file MotionSink.h
 *
 * \author Jackson Baldwin
 *
 * Representation of a motion sink
 */

#pragma once

#include "Component.h"
#include "WavChannel.h"

 /**
 * Representation of a motion sink
 */
class CMotionSink :
    public CComponent
{
public:
	/// Constructor
	CMotionSink() : CComponent() {}

	/// Destructor
	virtual ~CMotionSink() {}

	/// Copy constructor/disabled
	CMotionSink(const CMotionSink&) = delete;

	/// Assignment operator/disabled
	void operator=(const CMotionSink&) = delete;

	virtual void SetPressure(double pressure);

	/** Get the pressure of this motion sink
	* \returns Pressure */
	double GetPressure() { return mPressure; }

	/** Set the audio channel of this motion sink 
	* \param channel WavChannel to set */
	void SetAudioChannel(std::shared_ptr<CWavChannel> channel) { mChannel = channel; }

private:
	double mPressure = 1;	///< pressure of the motion sink

	/// Audio channel of this motion sink
	std::shared_ptr<CWavChannel> mChannel = nullptr;
};

