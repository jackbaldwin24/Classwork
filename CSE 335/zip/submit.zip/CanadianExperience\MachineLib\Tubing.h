/**
 * \file Tubing.h
 *
 * \author Jackson Baldwin
 *
 * Representation of our tubing
 */

#pragma once
#include "Component.h"
#include "AirSink.h"
#include "AirSource.h"
#include "EndPoint.h"
#include <vector>
#include <memory>

/**
 * Representation of our tubing
 */
class CTubing :
    public CComponent, public IAirSinkDestination
{
public:
	/// Constructor
	CTubing() : CComponent(), mSink(this) {}

	/// Destructor
	virtual ~CTubing() {}

	/// Copy constructor/disabled
	CTubing(const CTubing&) = delete;

	/// Assignment operator/disabled
	void operator=(const CTubing&) = delete;
	
	virtual void Draw(Gdiplus::Graphics* graphics, Gdiplus::Point location) override;
	
	virtual void SetPressure(double pressure) override;
	
	void AddClamp(int x, int y, double rotation, int speed);
	
	/** Get the air sink of this tubing
	* \returns AirSink of this tubing */
	CAirSink* GetSink() { return &mSink; }

	/** Get the air source of this tubing
	* \returns AirSource of this tubing */
	CAirSource* GetSource() { return &mSource; }

	
	/**
	 * Representation of a clamp
	 */
	class Clamp :
		public CEndPoint
	{
	public:
		/** Constructor
		 * \param x X location
		 * \param y Y location
		 * \param rotation Rotation
		 * \param speed Speed */
		Clamp(int x, int y, double rotation, int speed) 
		{
			SetPosition(x, y);
			SetRotation(rotation);
			SetSpeed(speed);
		}

		/// Destructor
		virtual ~Clamp() {}
	};

	/** Get the clamp at a certain index
	* \param i Index of clamp to retrieve 
	* \return Clamp at index i */
	std::shared_ptr<Clamp> GetClamp(int i) { return mClamps[i]; }

	/** Get the number of clamps of this tubing
	* \returns Number of clamps */
	int GetNumClamps() { return mClamps.size(); }

private:
	std::vector<std::shared_ptr<Clamp>> mClamps;	///< clamps of this tubing
	CAirSource mSource;								///< AirSource of this tubing
	CAirSink mSink;									///< AirSink of this tubing
};

