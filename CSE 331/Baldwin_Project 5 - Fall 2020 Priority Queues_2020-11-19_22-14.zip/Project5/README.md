# Name
Jackson Baldwin

# Feedback
I liked this project. The directions were straight-forward, it wasn't too difficult, and the recursive functions
didn't require hours of thinking like the last project did.

The only thing is that me and others are confused about how the heap sort can be in-place if we need
to use a max heap. I understand how to use the max heap, it's just that I don't get how it can be in-place.
# Time to Completion
4 hours

# Citations
Onsay's Heap Sort lecture

Onsay's Priority Queue lecture