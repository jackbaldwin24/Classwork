#include "pch.h"
#include "CppUnitTest.h"
#include <memory>
#include "WorkingMachine.h"
#include "Shape.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace Testing
{
	
	//class AFX_EXT_CLASS CComponentMock : public CComponent
	//{
	//public:
		//CComponentMock() : CComponent() {}
		/** Draw dummy function
		 * \param graphics Graphics object to draw on 
		 * \param location Location */
		//virtual void Draw(Gdiplus::Graphics* graphics, Gdiplus::Point location) override {}
	//};
	
	TEST_CLASS(CWorkingMachineTest)
	{
	public:

		TEST_METHOD_INITIALIZE(methodName)
		{
			extern wchar_t g_dir[];
			::SetCurrentDirectory(g_dir);
		}
		
		TEST_METHOD(TestNothing)
		{
			// This is an empty test just to ensure the system is working
		}

		TEST_METHOD(TestCWorkingMachineConstruct)
		{
			//CWorkingMachine machine;
		}

		TEST_METHOD(TestCWorkingMachineAddComponent)
		{
			//CWorkingMachine machine;
			//auto component = std::make_shared<CShape>();

			//machine.AddComponent(component);
		}

	};
}