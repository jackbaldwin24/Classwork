"""
Project 3 (Fall 2020) - Red/Black Trees
Name: Jackson Baldwin
"""

from __future__ import annotations
from typing import TypeVar, Generic, Callable, Generator
from Project3.RBnode import RBnode as Node
from copy import deepcopy
import queue

T = TypeVar('T')


class RBtree:
    """
    A Red/Black Tree class
    :root: Root Node of the tree
    :size: Number of Nodes
    """

    __slots__ = ['root', 'size']

    def __init__(self, root: Node = None):
        """ Initializer for an RBtree """
        # this alllows us to initialize by copying an existing tree
        self.root = deepcopy(root)
        if self.root:
            self.root.parent = None
        self.size = 0 if not self.root else self.root.subtree_size()

    def __eq__(self, other: RBtree) -> bool:
        """ Equality Comparator for RBtrees """
        comp = lambda n1, n2: n1 == n2 and (
            (comp(n1.left, n2.left) and comp(n1.right, n2.right)) if (n1 and n2) else True)
        return comp(self.root, other.root) and self.size == other.size

    def __str__(self) -> str:
        """ represents Red/Black tree as string """

        if not self.root:
            return 'Empty RB Tree'

        root, bfs_queue, height = self.root, queue.SimpleQueue(), self.root.subtree_height()
        track = {i: [] for i in range(height + 1)}
        bfs_queue.put((root, 0, root.parent))

        while bfs_queue:
            n = bfs_queue.get()
            if n[1] > height:
                break
            track[n[1]].append(n)
            if n[0] is None:
                bfs_queue.put((None, n[1] + 1, None))
                bfs_queue.put((None, n[1] + 1, None))
                continue
            bfs_queue.put((None, n[1] + 1, None) if not n[0].left else (n[0].left, n[1] + 1, n[0]))
            bfs_queue.put((None, n[1] + 1, None) if not n[0].right else (n[0].right, n[1] + 1, n[0]))

        spaces = 12 * (2 ** (height))
        ans = '\n' + '\t\tVisual Level Order Traversal of RBtree'.center(spaces) + '\n\n'
        for i in range(height):
            ans += f"Level {i + 1}: "
            for n in track[i]:
                space = int(round(spaces / (2 ** i)))
                if not n[0]:
                    ans += ' ' * space
                    continue
                ans += "{} ({})".format(n[0], n[2].value if n[2] else None).center(space, " ")
            ans += '\n'
        return ans

    def __repr__(self) -> str:
        return self.__str__()

    ################################################################
    ################### Complete Functions Below ###################
    ################################################################

    ######################## Static Methods ########################
    # These methods are static as they operate only on nodes, without explicitly referencing an RBtree instance

    @staticmethod
    def set_child(parent: Node, child: Node, is_left: bool) -> None:
        """
        Sets a child node to a parent's child, and a parent node to a child's parent
        :param parent: Parent node which will be set to _child_'s parent
        :param child: Child node which will be set to _parent_'s child
        :param is_left: true if _child_ is a left child
        """
        if is_left:
            parent.left = child
        else:
            parent.right = child
        if child is not None:
            child.parent = parent

    @staticmethod
    def replace_child(parent: Node, current_child: Node, new_child: Node) -> None:
        """
        Replaces a parent node's child
        :param parent: Parent node whose child will be replaced
        :param current_child: Child node which is currently in the tree
        :param new_child: Child node which will replace the current child
        """
        if current_child is parent.left:
            parent.left = new_child
        else:
            parent.right = new_child
        new_child.parent = parent

    @staticmethod
    def get_sibling(node: Node) -> Node:
        """
        Returns the sibling of a node (the node's parent's other child)
        :param node: Node to find the sibling of
        :return: Node which is the sibling of _node_
        """
        if node.parent is None:
            return None
        if node is node.parent.left:
            return node.parent.right
        else:
            return node.parent.left

    @staticmethod
    def get_grandparent(node: Node) -> Node:
        """
        Returns the grandparent of a node (the node's parent's parent)
        :param node: Node to find the grandparent of
        :return: Node which is the grandparent of _node_
        """
        if node.parent is None:
            return None
        return node.parent.parent

    @staticmethod
    def get_uncle(node: Node) -> Node:
        """
        Returns the uncle of a node (the node's parent's sibling)
        :param node: Node to find the uncle of
        :return: Node which is the uncle of Node
        """
        if node.parent is None or node.parent.parent is None:
            return None
        if node.parent is node.parent.parent.left:
            return node.parent.parent.right
        else:
            return node.parent.parent.left

    @staticmethod
    def get_predecessor(node: Node) -> Node:
        """
        Returns the node which comes before a node
        :param node: Node to find the predecessor of
        :return: Node which is the predecessor of _node_
        """
        node = node.left
        while node.right is not None:
            node = node.right
        return node

    @staticmethod
    def is_non_null_and_red(node: Node) -> bool:
        """
        Determines if a node is not None and it's color is red
        :param node: Node to check if not None and red
        :return: Bool representation of these properties being true
        """
        if node is None:
            return False
        return node.is_red

    @staticmethod
    def is_null_or_black(node: Node) -> bool:
        """
        Determines if a node is None or it's color is black
        :param node: Node to check if None or black
        :return: Bool representation of these properties being true
        """
        if node is None:
            return True
        return not node.is_red

    @staticmethod
    def are_both_children_black(node: Node) -> bool:
        """
        Determines if both of a node's children are black
        :param node: Node to check the colors of both children
        :return: Bool representation of these properties being true
        """
        if node.left is not None and node.left.is_red:
            return False
        if node.right is not None and node.right.is_red:
            return False
        return True

    ######################## Misc Utilities ##########################

    def min(self, node: Node) -> Node:
        """
        Returns the node containing the smallest value in the subtree rooted at _node_
        :param node: Root node of the subtree to check for the minimum value
        :return: the smallest node within the subtree rooted at _node_
        """
        if node is None:
            return None
        if node.left is None:
            return node
        return self.min(node.left)

    def max(self, node: Node) -> Node:
        """
        Returns the node containing the largest value in the subtree rooted at _node_
        :param node: Root node of the subtree to check for the minimum value
        :return: the largest node within the subtree rooted at _node_
        """
        if node is None:
            return None
        if node.right is None:
            return node
        return self.max(node.right)

    def search(self, node: Node, val: Generic[T]) -> Node:
        """
        Searches the subtree rooted at _node_ for a node containing the value _val_
        :param: node: Root node of the subtree to search
        :param val: Value to search for
        :return: Node containing the value _val_ in the subtree rooted at _node_
        """
        if node is None:
            return None
        if val is node.value:
            return node
        elif val < node.value:
            if node.left is None:
                return node
            return self.search(node.left, val)
        else:
            if node.right is None:
                return node
            return self.search(node.right, val)

    ######################## Tree Traversals #########################

    def inorder(self, node: Node) -> Generator[Node, None, None]:
        """
        Returns a generator object describing an inorder traversal of the subtree rooted at _node_
        :param node: Root node of the subtree to generate the traversal from
        :return: Generator object containing the inorder traversal
        """
        if node is not None:
            yield from self.inorder(node.left)
            yield node
            yield from self.inorder(node.right)

    def preorder(self, node: Node) -> Generator[Node, None, None]:
        """
        Returns a generator object describing a preorder traversal of the subtree rooted at _node_
        :param node: Root node of the subtree to generate the traversal from
        :return: Generator object containing the preorder traversal
        """

        if node is not None:
            yield node
            yield from self.preorder(node.left)
            yield from self.preorder(node.right)

    def postorder(self, node: Node) -> Generator[Node, None, None]:
        """
        Returns a generator object describing a postorder traversal of the subtree rooted at _node_
        :param node: Root node of the subtree to generate the traversal from
        :return: Generator object containing the postorder traversal
        """
        if node is not None:
            yield from self.postorder(node.left)
            yield from self.postorder(node.right)
            yield node

    def bfs(self, node: Node) -> Generator[Node, None, None]:
        """
        Returns a generator object describing a breadth first traversal of the subtree rooted at _node_
        :param node: Root node of the subtree to generate the traversal from
        :return: Generator object containing the breadth first traversal
        """
        q = queue.SimpleQueue()
        q.put(node)

        if node is None:
            yield

        while q.empty() is False:
            node_ = q.get()
            if node_.left is not None:
                q.put(node_.left)
            if node_.right is not None:
                q.put(node_.right)
            yield node_

    ################### Rebalancing Utilities ######################

    def left_rotate(self, node: Node) -> None:
        """
        Preforms a left tree rotation on the subtree rooted at _node_
        :param node: Root node of the subtree to perform the rotation on
        """
        right_left_child = node.right.left
        if node.parent is not None:
            self.replace_child(node.parent, node, node.right)
        else:
            self.root = node.right
            self.root.parent = None
        self.set_child(node.right, node, True)
        self.set_child(node, right_left_child, False)

    def right_rotate(self, node: Node) -> None:
        """
        Preforms a right tree rotation on the subtree rooted at _node_
        :param node: Root node of the subtree to perform the rotation on
        """
        left_right_child = node.left.right
        if node.parent is not None:
            self.replace_child(node.parent, node, node.left)
        else:
            self.root = node.left
            self.root.parent = None

        self.set_child(node.left, node, False)
        self.set_child(node, left_right_child, True)

    def insertion_repair(self, node: Node) -> None:
        """
        Repairs the subtree after the insertion of _node_ by maintaining RBTree properties
        :param node: Node which was inserted to perform the repair on
        """
        if node.parent is None:
            node.is_red = False
            return
        if not node.parent.is_red:
            return

        parent = node.parent
        grandparent = self.get_grandparent(node)
        uncle = self.get_uncle(node)

        if uncle is not None and uncle.is_red:
            parent.is_red = uncle.is_red = False
            grandparent.is_red = True
            self.insertion_repair(grandparent)
            return
        if node is parent.right and parent is grandparent.left:
            self.left_rotate(parent)
            node = parent
            parent = node.parent
        elif node is parent.left and parent is grandparent.right:
            self.right_rotate(parent)
            node = parent
            parent = node.parent
        parent.is_red = False
        grandparent.is_red = True
        if node is parent.left:
            self.right_rotate(grandparent)
        else:
            self.left_rotate(grandparent)

    def prepare_removal(self, node: Node) -> None:
        """
        Prepares the tree to remove _node_ by maintaining RBTree properties
        :param node: node which will be removed
        """

        def try_case_1() -> bool:
            """
            Determines if _node_ is red or _node_'s parent is None
            :return: True if _node_ is red or _node_'s parent is None, False otherwise
            """
            if node.is_red or node.parent is None:
                return True
            return False

        def try_case_2(sibling: Node) -> bool:
            """
            If _sibling_ is red, set _node_'s parent's color to red and _node_'s sibling to black,
            and rotate at _node_'s parent, with the direction depending on if the node is a left or right child
            :return: True if the _sibling_ is red, False if black
            """
            if sibling.is_red:
                node.parent.is_red = True
                sibling.is_red = False
                if node is node.parent.left:
                    self.left_rotate(node.parent)
                else:
                    self.right_rotate(node.parent)
                return True
            return False

        def try_case_3(sibling: Node) -> bool:
            """
            If _node_'s parent is black and both of _sibling_'s children are black,
            set the color of _sibling_ to red and call prepare_removal() on _node_'s parent
            :return: True if _node_'s parent is black and both of _sibling_'s children are black, False otherwise
            """
            if not node.parent.is_red and self.are_both_children_black(sibling):
                sibling.is_red = True
                self.prepare_removal(node.parent)
                return True
            return False

        def try_case_4(sibling: Node) -> bool:
            """
            If _node_'s parent is red and both of _sibling_'s children are black,
            set _node_'s parent's color to black and _sibling_'s color to red
            :return: True if _node_'s parent is red and both of _sibling_'s children are black, False otherwise
            """
            if node.parent.is_red and self.are_both_children_black(sibling):
                node.parent.is_red = False
                sibling.is_red = True
                return True
            return False

        def try_case_5(sibling: Node) -> bool:
            """
            If _sibling_'s left child is red, _sibling_'s right child is black, and _node_ is a left child,
            set _sibling_'s color to red and _sibling_'s left child's color black, and rotate right at sibling
            :return: True if _sibling_'s left child is red, _sibling_'s right child is black, and _node_
                is a left child, and False otherwise
            """
            if self.is_non_null_and_red(sibling.left) and self.is_null_or_black(
                    sibling.right) and node is node.parent.left:
                sibling.is_red = True
                sibling.left.is_red = False
                self.right_rotate(sibling)
                return True
            return False

        def try_case_6(sibling: Node) -> bool:
            """
            If _sibling_'s left child is black, _sibling_'s right child is red, and _node_ is a right child,
            set _sibling_'s color to red and _sibling_'s right child's color to black, and rotate left at sibling
            :return: True if _sibling_'s left child is black, _sibling_'s right child is red, and _node_
                is a right child, and False otherwise
            """
            if self.is_null_or_black(sibling.left) and self.is_non_null_and_red(
                    sibling.right) and node is node.parent.right:
                sibling.is_red = True
                sibling.right.is_red = False
                self.left_rotate(sibling)
                return True
            return False

        if try_case_1():
            return
        sibling_ = self.get_sibling(node)
        if try_case_2(sibling_):
            sibling_ = self.get_sibling(node)
        if try_case_3(sibling_):
            return
        if try_case_4(sibling_):
            return
        if try_case_5(sibling_):
            sibling_ = self.get_sibling(node)
        if try_case_6(sibling_):
            sibling_ = self.get_sibling(node)
        sibling_.is_red = node.parent.is_red
        node.parent.is_red = False
        if node is node.parent.left:
            sibling_.right.is_red = False
            self.left_rotate(node.parent)
        else:
            sibling_.left.is_red = False
            self.right_rotate(node.parent)

    ##################### Insertion and Removal #########################

    def insert(self, node: Node, val: Generic[T]) -> None:
        """
        Inserts a new node into the subtree rooted at _node_ with the value _val_
        :param node: Root node of the subtree of which a new node will be inserted
        :param val: Value of the new node which will be inserted into the subtree
        """

        if node is None:
            node = self.root = Node(val)
            self.size += 1
            self.insertion_repair(self.root)

        found_node = self.search(node, val)

        if val < found_node.value:
            found_node.left = Node(val, parent=found_node)
            self.size += 1
            self.insertion_repair(found_node.left)
        elif val > found_node.value:
            found_node.right = Node(val, parent=found_node)
            self.size += 1
            self.insertion_repair(found_node.right)

    def bst_remove(self, sub_root: Node, val: Generic[T]) -> None:
        """
        Removes a node containing the value _val_ from the subtree rooted at _node_
        :param sub_root: The root of the subtree which the node will be removed from
        :param val: Value of the node to remove
        """
        node = self.search(sub_root, val)
        if node is None or node.value != val:
            return
        if node.right is None and node.left is None:
            par = node.parent
            if par is None:
                self.root = None
            elif par.right is not None and par.right.value == val:
                par.right = None
            else:
                par.left = None
            self.size -= 1
            return
        if node.right is None or node.left is None:
            par = node.parent
            if node.right is not None:
                child = node.right
            else:
                child = node.left
            if par is None:
                self.root = child
                self.root.is_red = False
            elif par.right is not None and par.right.value == val:
                par.right = child
            else:
                par.left = child
            child.parent = par
            self.size -= 1
            return
        min_right = self.min(node.right)
        self.bst_remove(sub_root, min_right.value)
        node.value = min_right.value

    def remove_node(self, sub_root: Node, node_to_remove: Node) -> None:
        """
        If _node_ has two children, remove _node_to_remove_'s predecessor, and set the value
        of _node_to_remove_ to the value of its predecessor. Else, call prepare_removal() if
        _node_to_remove is red, then call bst_remove to remove the node.
        :param sub_root: The root of the subtree which the node will be removed from
        :param node_to_remove: Node which is to be removed
        """
        if node_to_remove.left is not None and node_to_remove.right is not None:
            pred_node = self.get_predecessor(node_to_remove)
            pred_val = pred_node.value
            self.remove_node(sub_root, pred_node)
            node_to_remove.value = pred_val
            return
        if not node_to_remove.is_red:
            self.prepare_removal(node_to_remove)
        self.bst_remove(sub_root, node_to_remove.value)

    def remove(self, node: Node, val: Generic[T]) -> None:
        """
        Removes a node containing the value _val_ from the subtree rooted at _node_
        :param node: The root of the subtree which the node will be removed from
        :param val: value of the node to be removed
        """
        node_to_remove = self.search(node, val)
        if node_to_remove is not None and node_to_remove.value is val:
            self.remove_node(node, node_to_remove)
