/**
 * \file Chime.h
 *
 * \author Jackson Baldwin
 *
 * Representation of a chime in the machine
 */

#pragma once

#include "Component.h"
#include "Polygon.h"
#include "MotionSink.h"

/**
 * Representation of a chime in the machine
 */
class CChime :
    public CMotionSink
{
public:
	CChime(int length);

	/// Destructor
	virtual ~CChime() {}

	/// Copy constructor/disabled
	CChime(const CChime&) = delete;

	/// Assignment operator/disabled
	void operator=(const CChime&) = delete;

	/** Set the chime to be normal or rocking
	* \param rock Bool representing if the chime rocks */
	void SetRock(bool rock) { mRock = rock; }

	/** Set the current time of this machine
	* \param time Time to set */
	virtual void SetTime(double time) override { mTime = time; }

	virtual void Draw(Gdiplus::Graphics* graphics, Gdiplus::Point location) override;

	virtual void SetPressure(double pressure) override;

private:
	CPolygon mMount;			///< Image for the mount
	CPolygon mHammer;			///< Image for the hammer
	CPolygon mChime;			///< Image for the actual chime

	bool mRock = false;			///< bool to determine if chime rocks

	double mTime = 0;			///< current time in seconds
	double mTimeStruck = -2;	///< time the chime was struck in seconds

	int mLength = 0;			///< length of this chime in pixels
};

