# Name
Jackson Baldwin

# Feedback
Finding out how to do inversion count was a bit tricky, but other than that it wasn't too difficult

# Time to Completion
roughly 5 hours over a span of two days

# Citations
1) Onsay's Insertion Sort: https://d2l.msu.edu/d2l/le/content/1193085/viewContent/9253937/View  
2) Onsay's Merge Sort: https://d2l.msu.edu/d2l/le/content/1193085/viewContent/9254031/View
3) Video discussing inversion count: https://www.youtube.com/watch?v=owZhw-A0yWE
4) Generating a dict with user's interests mapped to ints in ascending order: https://stackoverflow.com/questions/34308635/sort-elements-with-specific-order-in-python
5) Accessing first element in a dictionary: https://www.geeksforgeeks.org/python-get-the-first-key-in-dictionary/