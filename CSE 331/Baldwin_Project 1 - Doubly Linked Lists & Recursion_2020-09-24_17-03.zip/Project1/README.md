# Name
Jackson Baldwin

# Feedback
The application problem was challenging, but I was able to figure it out after realizing that a boolean could also contain the value None, instead of just True or False, leaving me with three possible outcomes on my Floyd algorithm. Other than that, all the other functions weren't too difficult to implement.

# Time to Completion
3-4 hours total

# Citations
https://www.youtube.com/watch?v=MFOAbpfrJ8g&ab_channel=HackerRank