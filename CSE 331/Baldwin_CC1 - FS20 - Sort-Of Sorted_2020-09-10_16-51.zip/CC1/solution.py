"""
Jackson Baldwin
Coding Challenge 1 - Sort of Sorted - Solution Code
CSE 331 Fall 2020
Professor Sebnem Onsay
"""
from typing import List


def sort_of_sorted(data: List[str]) -> (int, List[str]):
    """
    Determine the longest sublist of strings in alphabetical order.
    :param data: [list] of strings in semi-sorted order
    :return: tuple containing
        [0]: [int] length of longest sorted sublist
        [1]: [list] longest sorted sublist of strings
    """
    start_index = 0
    end_index = 0
    k = 1

    largest_start_index = 0
    largest_end_index = 0
    largest_k = 1

    if not data:
        return 0, []

    for i in range(len(data) - 1):
        if data[i] <= data[i + 1]:
            k += 1
            end_index = i + 1
            if k > largest_k:
                largest_k = k
                largest_start_index = start_index
                largest_end_index = end_index
        else:
            k = 1
            start_index = i + 1
            end_index = i + 1

    return largest_k, data[largest_start_index:largest_end_index + 1]
