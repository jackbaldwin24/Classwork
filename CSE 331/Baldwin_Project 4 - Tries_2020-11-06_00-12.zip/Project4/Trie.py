"""
Jackson Baldwin
Project 4 - Tries
CSE 331 Fall 2020
Professor Sebnem Onsay
"""

from __future__ import annotations
from typing import Tuple, Dict, List


class TrieNode:
    """
    Implementation of a trie node.
    """

    # DO NOT MODIFY

    __slots__ = "children", "is_end"

    def __init__(self, arr_size: int = 26) -> None:
        """
        Constructs a TrieNode with arr_size slots for child nodes.
        :param arr_size: Number of slots to allocate for child nodes.
        :return: None
        """
        self.children = [None] * arr_size
        self.is_end = 0

    def __str__(self) -> str:
        """
        Represents a TrieNode as a string.
        :return: String representation of a TrieNode.
        """
        if self.empty():
            return "..."
        children = self.children  # to shorten proceeding line
        return str(
            {chr(i + ord("a")) + "*" * min(children[i].is_end, 1): children[i] for i in range(26) if children[i]})

    def __repr__(self) -> str:
        """
        Represents a TrieNode as a string.
        :return: String representation of a TrieNode.
        """
        return self.__str__()

    def __eq__(self, other: TrieNode) -> bool:
        """
        Compares two TrieNodes for equality.
        :return: True if two TrieNodes are equal, else False.
        """
        if not other or self.is_end != other.is_end:
            return False
        return self.children == other.children

    # Implement Below

    def empty(self) -> bool:
        """
        Checks if a node is empty.
        :return: Bool representation of the node having no children.
        """
        for node in self.children:
            if node is not None:
                return False
        return True

    @staticmethod
    def _get_index(char: str) -> int:
        """
        Returns the integer index of a character in a-z or A-Z.
        :param char: character to get the index of.
        :return: Index representation of the character.
        """
        char = char.lower()
        return ord(char) - 97

    def get_child(self, char: str) -> TrieNode:
        """
        Returns the child TrieNode at a character's index .
        :param char: character of child TrieNode to receive.
        :return: The child TrieNode at the index of _char_.
        """
        return self.children[self._get_index(char)]

    def set_child(self, char: str) -> None:
        """
        Creates a new TrieNode and stores it in it's children at the character's index.
        :param char: character of child TrieNode to create.
        :return: None.
        """
        self.children[self._get_index(char)] = TrieNode()

    def delete_child(self, char: str) -> None:
        """
        Deletes the child TrieNode at the character's index.
        :param char: Character of child TrieNode to delete.
        :return: None.
        """
        self.children[self._get_index(char)] = None


class Trie:
    """
    Implementation of a trie.
    """

    # DO NOT MODIFY

    __slots__ = "root", "unique", "size"

    def __init__(self) -> None:
        """
        Constructs an empty Trie.
        :return: None.
        """
        self.root = TrieNode()
        self.unique = 0
        self.size = 0

    def __str__(self) -> str:
        """
        Represents a Trie as a string.
        :return: String representation of a Trie.
        """
        return "Trie Visual:\n" + str(self.root)

    def __repr__(self) -> str:
        """
        Represents a Trie as a string.
        :return: String representation of a Trie.
        """
        return self.__str__()

    def __eq__(self, other: Trie) -> bool:
        """
        Compares two Tries for equality.
        :return: True if two Tries are equal, else False.
        """
        return self.root == other.root

    # Implement Below

    def add(self, word: str) -> int:
        """
        Adds a word to the Trie by traversing the Trie from the root downward
        and creating TrieNodes when necessary.
        :param word: [string] Word to be added to the Trie.
        :return: [int] The number of times _word_ is in the Trie.
        """

        def add_inner(node: TrieNode, index: int) -> int:
            """
            Recursive helper function which adds children to the current node at word[index],
            and calls itself with the child it just added, and increments index by 1.
            :param node: Current TrieNode to have its child set.
            :param index: The index of _word_ to be added.
            """
            if index is len(word):
                if node.is_end == 0:
                    self.unique += 1
                node.is_end += 1
                self.size += 1
                return node.is_end
            if node.get_child(word[index]) is None:
                node.set_child(word[index])

            return add_inner(node.get_child(word[index]), index + 1)

        return add_inner(self.root, 0)

    def search(self, word: str) -> int:
        """
        Traverses the Trie from the root downward until _word_ is found or a child TrieNode is None.
        :param word: [string] Word to be searched for in the Trie.
        :return: [int] The number of times _word_ is in the Trie.
        """

        def search_inner(node: TrieNode, index: int) -> int:
            """
            Recursive helper function which traverses the Trie which calls itself
            with the child node at _word_'s index, and increments index by 1.
            :param node: Current TrieNode being analysed.
            :param index: Index of _word_ being searched.
            """
            if index is len(word):
                return node.is_end
            if node.get_child(word[index]) is None:
                return 0
            return search_inner(node.get_child(word[index]), index + 1)

        return search_inner(self.root, 0)

    def delete(self, word: str) -> int:
        """
        Deletes a word from the Trie and returns the number of times a word was in the Trie.
        :param word: [string] Word to be deleted from the Trie.
        :return: [int] The number of times _word_ was in the Trie.
        """

        def delete_inner(node: TrieNode, index: int) -> Tuple[int, bool]:
            """
            Recursive helper function which traverses the Trie, and deletes nodes on the way back up
            the recursion if it finds the end node.
            :param node: Current node being analysed.
            :param index: Current index of the word to be deleted.
            :return: Tuple containing the number of times the word was in the tree,
                    along with a bool representing if the node should be deleted or not.
            """


            data = (None, None)

            if index < len(word) and node is not None:
                data = delete_inner(node.get_child(word[index]), index + 1)

            if data[1]:
                node.delete_child(word[index])

            if index == len(word) and node is not None:
                self.size -= node.is_end
                self.unique -= 1
                temp = node.is_end
                node.is_end = 0
                if node.empty():
                    result, delete = temp, True
                else:
                    result, delete = temp, False

            elif node is None and index < len(word):
                result, delete = 0, False

            elif node.empty() and data[1] and node.is_end == 0:
                result, delete = data[0], True
            else:
                result, delete = data[0], False

            return result, delete

        return delete_inner(self.root, 0)[0]

    def __len__(self) -> int:
        """
        Returns the number of words in the Trie.
        :return: [int] The number of words in the Trie.
        """
        return self.size

    def __contains__(self, word: str) -> bool:
        """
        Checks if a word is in the Trie.
        :param word: [string] The word to check the Trie for].
        :return: Bool representation of the word being in the Trie.
        """
        return self.search(word) > 0

    def empty(self) -> bool:
        """
        Checks if the Trie is empty.
        :return: Bool representation of the Trie being empty.
        """
        return self.size == 0

    def get_vocabulary(self, prefix: str = "") -> Dict[str, int]:
        """
        Returns a dictionary of all the words starting with a prefix,
        and the number of times they exist in the Trie.
        :param prefix: [string] Prefix of the words to be added.
        :return: Return value here.
        """

        words = {}

        def get_vocabulary_inner(node, suffix):
            """
            Recursive helper function which traverses the Trie and adds words to _words_
            if it finds an end node.
            :param node: Current node being analysed
            :param suffix: Current string to be added to _words_ if it finds an end node.
            :return: None.
            """
            nonlocal words
            if node is None:
                return
            i = 97
            for child in node.children:
                if child is not None:
                    temp = suffix
                    suffix += chr(i)
                    if child.is_end:
                        words[prefix + suffix] = child.is_end
                    get_vocabulary_inner(child, suffix)
                    suffix = temp
                i += 1

        if prefix == "":
            get_vocabulary_inner(self.root, "")
        else:
            node_ = self.root
            for ch in prefix:
                if node_ is not None:
                    node_ = node_.get_child(ch)
            if node_ is not None:
                if node_.is_end:
                    words[prefix] = node_.is_end
                get_vocabulary_inner(node_, "")

        return words

    def autocomplete(self, word: str) -> Dict[str, int]:
        """
        Finds every word and its count in the Trie that matches the template of _word_.
        :param word: Template to check the Trie for. If a letter in _word_ is a '.', then it can be any letter.
        :return: A dictionary representing every word that matches the template of _word_, and the number of
                times it is in the Trie
        """

        words = {}

        def autocomplete_inner(node, prefix, index):
            """
            Recursive helper function that traverses the Trie, and adds words and their count to _words_
            if they match the template _word_.
            :param node: Current node that is being analysed.
            :param prefix: Current string to be added to _words_ if it finds an end node.
            :param index: Current index of _word_.
            :return: None.
            """
            nonlocal words
            if node is None or index >= len(word):
                return
            i = 97
            for child in node.children:
                if child is not None and (word[index] == '.' or word[index] == chr(i)):
                    temp = prefix
                    prefix += chr(i)
                    if child.is_end and len(prefix) == len(word):
                        words[prefix] = child.is_end
                    autocomplete_inner(child, prefix, index + 1)
                    prefix = temp
                i += 1

        autocomplete_inner(self.root, "", 0)
        return words


class TrieClassifier:
    """
    Implementation of a trie-based text classifier.
    """

    # DO NOT MODIFY

    __slots__ = "tries"

    def __init__(self, classes: List[str]) -> None:
        """
        Constructs a TrieClassifier with specified classes.
        :param classes: List of possible class labels of training and testing data.
        :return: None.
        """
        self.tries = {}
        for cls in classes:
            self.tries[cls] = Trie()

    @staticmethod
    def accuracy(labels: List[str], predictions: List[str]) -> float:
        """
        Computes the proportion of predictions that match labels.
        :param labels: List of strings corresponding to correct class labels.
        :param predictions: List of strings corresponding to predicted class labels.
        :return: Float proportion of correct labels.
        """
        correct = sum([1 if label == prediction else 0 for label, prediction in zip(labels, predictions)])
        return correct / len(labels)

    # Implement Below

    def fit(self, class_strings: Dict[str, List[str]]) -> None:
        """
        Adds every word from each tweet in the list of strings to their corresponding class.
        :param class_strings: Dict of strings representing classes mapped to their list of strings representing tweets.
        :return: None.
        """
        for cls in class_strings:
            tweets = class_strings[cls]
            self.tries[cls] = Trie()
            for tweet in tweets:
                words = tweet.split()
                for word in words:
                    self.tries[cls].add(word)

    def predict(self, strings: List[str]) -> List[str]:
        """
        Predicts the most appropriate class for each tweet by comparing the number of occurrences
        of the words in each tweet in each class divided by the size of the class.
        :param strings: Tweets to find their predicted classes.
        :return: List of strings representing the tweets' predicted classes.
        """

        result = []
        for tweet in strings:
            max_count, max_cls = 0, ""
            words = tweet.split()
            for cls in self.tries:
                count = 0
                for word in words:
                    count += self.tries[cls].search(word)
                count /= len(self.tries[cls])
                if count > max_count:
                    max_count, max_cls = count, cls
            result.append(max_cls)
        return result
