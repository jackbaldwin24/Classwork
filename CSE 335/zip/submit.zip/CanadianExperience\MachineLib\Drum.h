/**
 * \file Drum.h
 *
 * \author Jackson Baldwin
 *
 * Representation of a drum
 */

#pragma once

#include "MotionSink.h"
#include "Polygon.h"

/**
 * Representation of a drum
 */
class CDrum :
    public CMotionSink
{
public:
	CDrum();

	/// Destructor
	virtual ~CDrum() {}

	/// Copy constructor/disabled
	CDrum(const CDrum&) = delete;

	/// Assignment operator/disabled
	void operator=(const CDrum&) = delete;

	virtual void Draw(Gdiplus::Graphics* graphics, Gdiplus::Point location) override;

private:
	CPolygon mDrumImage;	///< Image of the drum
};

