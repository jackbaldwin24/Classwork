/**
 * \file FlagFactory.cpp
 *
 * \author Jackson Baldwin
 */

#include "pch.h"
#include "FlagFactory.h"
#include "ImageDrawable.h"

using namespace Gdiplus;
using namespace std;

CFlagFactory::CFlagFactory()
{
}


CFlagFactory::~CFlagFactory()
{
}


/** This is a concrete factory method that creates our Flag actor.
* \returns Pointer to an actor object.
*/
std::shared_ptr<CActor> CFlagFactory::Create()
{
	shared_ptr<CActor> actor = make_shared<CActor>(L"Flag");

    auto flag = make_shared<CImageDrawable>(L"Flag", L"images/flag.png");
    flag->SetCenter(Point(127, 236));
    flag->SetPosition(Point(0, 0));
    actor->SetRoot(flag);

    actor->AddDrawable(flag);

    return actor;
}

