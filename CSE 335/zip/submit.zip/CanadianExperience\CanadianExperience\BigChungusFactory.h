/**
 * \file BigChungusFactory.h
 *
 * \author Jackson Baldwin
 *
 * Factory class that builds the Big Chungus character
 */

#pragma once

#include <memory>
#include "ActorFactory.h"
#include "Actor.h"

/**
 * Factory class that builds the Big Chungus character
 */
class CBigChungusFactory :
    public CActorFactory
{
public:
    virtual std::shared_ptr<CActor> Create() override;
};

