/**
 * \file MachineTwoFactory.h
 *
 * \author Jackson Baldwin
 *
 * Creates a machine of type 2
 */

#pragma once

#include <memory>
#include "WorkingMachine.h"

/**
 * Creates a machine of type 2
 */
class CMachineTwoFactory
{
public:
	CMachineTwoFactory() {}

	std::shared_ptr<CWorkingMachine> CreateMachine();
};

