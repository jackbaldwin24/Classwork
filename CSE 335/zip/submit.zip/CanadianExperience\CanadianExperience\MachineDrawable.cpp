/**
 * \file MachineDrawable.cpp
 *
 * \author Jackson Baldwin
 */

#include "pch.h"
#include "MachineDrawable.h"
#include "MachineDlg.h"
#include "MachineFactory.h"

/// offset so y value is near middle of machine
const int YOffset = -100;

/// max distance for the hittest
const int MaxDistance = 200;


/**
 * Constructor of the machine adapter class
 * \param name Name of this drawable
 */
CMachineDrawable::CMachineDrawable(const std::wstring& name) : CDrawable(name)
{
	CMachineFactory factory;

	mMachine = factory.CreateMachine();

	if (name == L"1")
	{
		mMachine->SetMachineNumber(1);
	}
	else if (name == L"2")
	{
		mMachine->SetMachineNumber(2);
	}
}

/**
 * Draws the machine
 * \param graphics Graphics context to draw in
 */
void CMachineDrawable::Draw(Gdiplus::Graphics* graphics)
{
	float scale = 0.6f;

	// get the correct frame for the machine
	int currFrame = mTimeline->GetCurrentFrame() - mStartFrame;
	if (currFrame < 0) 
	{ 
		currFrame = 0; 
	}
	
	// loop through any missed frames
	if (currFrame != mPrevFrame + 1 && currFrame != mPrevFrame)
	{
		for (int frame = mPrevFrame + 1; frame <= currFrame; frame++)
		{
			mMachine->SetMachineFrame(frame);
		}
		
	}
	mPrevFrame = currFrame;
	
	// save the graphics context
	auto save = graphics->Save();
	
	// scale the machine
	graphics->TranslateTransform((float)mPlacedPosition.X,
		(float)mPlacedPosition.Y);
	graphics->ScaleTransform(scale, scale);

	// set the frame
	mMachine->SetMachineFrame(currFrame);

	// actually draw the machine
	mMachine->DrawMachine(graphics);
	
	// restore graphics
	graphics->Restore(save);
}

/**
 * Sets the position of this machine
 * \param x 
 * \param y 
 */
void CMachineDrawable::SetPosition(int x, int  y)
{
	mPlacedPosition.X = x;
	mPlacedPosition.Y = y;
}

/**
 * Brings up the dialog box to change the machine
 */
void CMachineDrawable::ChangeMachine()
{
	CMachineDlg dlg(mMachine);
	if (dlg.DoModal() == IDOK)
	{
	}
}

/**
 * Determines if the machine was double clicked
 * \param pos Position of the double click
 * \returns True if machine hit, false otherwise
 */
bool CMachineDrawable::HitTest(Gdiplus::Point pos)
{
	int x = mPlacedPosition.X - pos.X;
	int y = mPlacedPosition.Y - pos.Y + YOffset;
	return sqrt(pow(x, 2.0) + pow(y, 2.0)) < 200;
}


/**
 * Sets the timeline of the machine
 * \param timeline Timeline to set
 */
void CMachineDrawable::SetTimeline(CTimeline* timeline)
{
	CDrawable::SetTimeline(timeline);
	mTimeline = timeline;
}
