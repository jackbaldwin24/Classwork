from Trie import TrieNode, Trie

trie = Trie()


dict_ = trie.autocomplete("f..t")
print(dict_)
