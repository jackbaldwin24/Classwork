/**
 * \file MachineDrawable.h
 *
 * \author Jackson Baldwin
 *
 * Our machine adapter class
 */

#pragma once
#include "Drawable.h"
#include <memory>
#include "Machine.h"
#include "Timeline.h"

/**
 * Our machine adapter class
 */
class CMachineDrawable :
    public CDrawable
{
public:
    CMachineDrawable(const std::wstring& name);

    virtual void Draw(Gdiplus::Graphics* graphics) override;

    void SetPosition(int x, int y);

    void SetTimeline(CTimeline* timeline);

    void ChangeMachine();

    virtual bool HitTest(Gdiplus::Point pos) override;

    /** Gets the current machine number
    * \returns Machine number */
    int GetMachineNumber() { return mMachine->GetMachineNumber(); }

    /** Sets the current machine number
    * \param num  Machine number */
    void SetMachineNumber(int num) { mMachine->SetMachineNumber(num); }

    /** Sets the start frame of the machine
    * \param frame frame to set as the start frame */
    void SetStartFrame(int frame) { mStartFrame = frame; }

    /** Gets the current machine number
    * \returns num  Machine number */
    int GetStartFrame() { return mStartFrame; }

private:
    std::shared_ptr<CMachine> mMachine = nullptr;       ///< the machine we are adapting
    CTimeline* mTimeline = nullptr;                     ///< the timeline associated with this machine
    int mPrevFrame = -1;                                ///< previous frame during playback
    int mStartFrame = 0;                                ///< the frame the machine starts playing on
};

