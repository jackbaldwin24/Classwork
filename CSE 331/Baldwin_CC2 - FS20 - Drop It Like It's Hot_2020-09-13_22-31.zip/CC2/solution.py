"""
Jackson Baldwin
Coding Challenge 2 - Drop It Like It's Hot - Solution
CSE 331 Fall 2020
Professor Sebnem Onsay
"""
from typing import List, Tuple


def count(grid: List[List[int]], row: int, col: int, k: int) -> int:
    """
        Given an n x n 2D list of 0's and 1's and an integer k, determine the greatest number of 1's
        that can be covered by a square of size k x k.
        :param grid: [list[list[int]]] a square 2D list of 0, 1 integers
        :param row: [int] the row of the grid where the upper-left corner of the k x k square resides
        :param col: [int] the column of the grid where the upper-left corner of the k x k square resides
        :param k: [int] the size of the square placed to cover 1's
        :return: [int] a count of the 1's within the k x k square

    """
    one_count = 0

    for i in range(k):
        for j in range(k):
            if grid[row + i][col + j] == 1:
                one_count += 1
    return one_count


def firefighter(grid: List[List[int]], k: int) -> Tuple[int, int, int]:
    """
    Given an n x n 2D list of 0's and 1's and an integer k, determine the greatest number of 1's
    that can be covered by a square of size k x k. Return a tuple (a, b, c) where
        a = number of 1's this optimal k x k square covers
        b = the row of the top left corner of this square
        c = the col of the top left corner of this square
    :param grid: [list[list[int]]] a square 2D list of 0, 1 integers
    :param k: [int] the size of the square placed to cover 1's
    :return: [tuple[int, int, int]] a tuple (a, b, c) where
        a = number of 1's this optimal k x k square covers
        b = the row of the top left corner of this square
        c = the col of the top left corner of this square
    """

    max_row = 0
    max_col = 0
    max_count = 0

    max_search_index = len(grid) - k + 1

    if k == 0:
        return 0, 0, 0
    if grid == [[]]:
        return 0, 0, 0

    for row in range(max_search_index):
        for col in range(max_search_index):
            fire_count = count(grid, row, col, k)

            if fire_count > max_count:
                max_row = row
                max_col = col
                max_count = fire_count

    return max_count, max_row, max_col
