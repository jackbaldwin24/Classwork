/**
 * \file AirSource.h
 *
 * \author Jackson Baldwin
 *
 * Representation of an air source
 */

#pragma once

#include "AirSink.h"
#include "EndPoint.h"

/**
 * Representation of an air source
 */
class CAirSource : public CEndPoint
{
public:
    /// Constructor
    CAirSource() : CEndPoint() {}

    /// Destructor
    virtual ~CAirSource() {}
    
    /// Copy constructor (disabled)
    CAirSource(const CAirSource&) = delete;

    /// Assignment operator (disabled)
    void operator=(const CAirSource&) = delete;
    
    void SetPressure(double pressure);

    /** Sets the sink of this air source
    * \param sink AirSink to set */
    void SetSink(CAirSink* sink) { mAirSink = sink; mAirSink->SetSource(this); }

    /** Gets the sink of this air source
    * \returns AirSink */
    CAirSink* GetSink() { return mAirSink; }

    /** Determines if the air sink has a component
    * \returns true or false */
    bool IsValid() { return mAirSink != nullptr; }

private:
    CAirSink* mAirSink = nullptr;   ///< the air sink of this air source
};

