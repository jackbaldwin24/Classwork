# Name
Jackson Baldwin

# Feedback
I felt like most of this project was just looking at the psuedocode from lecture and zybooks and implementing
it in the RBtree class. I wish there were some sort of application problem which we could actually use the tree
for something. However, Zybooks and the lectures definitely made the project easier to understand and complete.

# Time to Completion
~4 hours

# Citations
Zybooks 25.5 - 25.8
Onsay's BST insert and remove algorithms: https://d2l.msu.edu/d2l/le/content/1193085/viewContent/9680144/View