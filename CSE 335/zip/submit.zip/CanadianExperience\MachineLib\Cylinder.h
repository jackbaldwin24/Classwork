/**
 * \file Cylinder.h
 *
 * \author Jackson Baldwin
 *
 * Representation of our cylinder
 */

#pragma once
#include "MotionSource.h"
#include "Component.h"
#include "Polygon.h"
#include "AirSink.h"
#include "MotionSink.h"

/**
 * Representation of our cylinder
 */
class CCylinder :
    public CMotionSource, public IAirSinkDestination
{
public:
	CCylinder();

	/// Destructor
	virtual ~CCylinder() {}

	/// Copy constructor/disabled
	CCylinder(const CCylinder&) = delete;

	/// Assignment operator/disabled
	void operator=(const CCylinder&) = delete;

	virtual void Draw(Gdiplus::Graphics* graphics, Gdiplus::Point location) override;

	virtual void SetPressure(double pressure) override;

	virtual void SetPosition(int x, int y);

	void SetSinkPosition();

	void SetRotation(double rotation);

	/** Set the max extent of this cylinder
	* \param maxExtent Maximum extent of this cylinder */
	void SetMaxExtent(double maxExtent) { mMaxExtent = maxExtent; }

	/** Get the air sink of this cylinder
	* \returns AirSink of this cylinder */
	CAirSink* GetSink() { return &mSink; }

private:
	double mPressure = 0.0;		///< current pressure of this cylinder
	double mMaxExtent = 1;		///< percentage of the maximum extention
	double mRotation = 0;		///< rotation value in number of rotations
	
	CPolygon mMount;			///< Image for the mount
	CPolygon mRam;				///< Image for the ram
	CPolygon mCylinder;			///< Image for the actual cylinder

	CAirSink mSink;				///< The air sink of this cylinder
};

