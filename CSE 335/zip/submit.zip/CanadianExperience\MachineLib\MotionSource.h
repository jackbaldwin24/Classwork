/**
 * \file MotionSource.h
 *
 * \author Jackson Baldwin
 *
 * Representation of a motion source
 */

#pragma once
#include "Component.h"
#include "MotionSink.h"
#include <memory>

/**
 * Representation of a motion source
 */
class CMotionSource : public CComponent
{
public:
	/// Constructor
	CMotionSource() : CComponent() {}
	
	/// Destructor
	virtual ~CMotionSource() {}

	/// Copy constructor/disabled
	CMotionSource(const CMotionSource&) = delete;

	/// Assignment operator/disabled
	void operator=(const CMotionSource&) = delete;

	/** Set the motion sink of this motion source
	* \param sink MotionSink to be set */
	void SetMotionSink(std::shared_ptr<CMotionSink> sink) { mMotionSink = sink; }

	/** Set the pressure of this motion sink
	* \param pressure Pressure to be set */
	virtual void SetPressure(double pressure) { mMotionSink->SetPressure(pressure); }
	

private:
	std::shared_ptr<CMotionSink> mMotionSink;	///< motion sink of this motion source
};

