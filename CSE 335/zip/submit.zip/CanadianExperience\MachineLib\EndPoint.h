/**
 * \file EndPoint.h
 *
 * \author Jackson Baldwin
 *
 * Representation of a tube endpoint
 */

#pragma once

/**
 * Representation of a tube endpoint
 */
class CEndPoint
{
public:
	/// Contructor
	CEndPoint() {}

	/// Destructor
	virtual ~CEndPoint() {}

	/// Copy constructor/disabled
	CEndPoint(const CEndPoint&) = delete;

	/// Assignment operator/disabled
	void operator=(const CEndPoint&) = delete;

	/** Set the position of this endpoint
	* \param x X position
	* \param y Y position */
	void SetPosition(int x, int y) { mPoint.X = x; mPoint.Y = y; }

	/** Get the position of this endpoint
	* \returns Point representing end of this endpoint */
	Gdiplus::Point GetPosition() { return mPoint; }

	/** Set the speed of this endpoint
	* \param speed Speed to set */
	void SetSpeed(int speed) { mSpeed = speed; mCurrentSpeed = speed; }

	/** Get the speed of this endpoint
	* \returns Speed of this endpoint */
	int GetSpeed() { return mSpeed; }

	/** Set the current speed of this endpoint
	* \param speed Current speed to set */
	void SetCurrentSpeed(int speed) { mCurrentSpeed = speed; }
	
	/** Get the current speed of this endpoint
	* \returns Current speed of this endpoint */
	int GetCurrentSpeed() { return mCurrentSpeed; }

	/** Set the rotation of this endpoint
	* \param rotation Rotation to set */
	void SetRotation(double rotation) { mRotation = rotation; }

	/** Get the rotation of this endpoint
	* \returns Rotation of this endpoint */
	double GetRotation() { return mRotation; }

private:
	double mRotation = 0;							///< rotation of this endpoint
	int mSpeed = 0;									///< speed of this endpoint
	int mCurrentSpeed = 0;							///< current speed of this endpoint
	Gdiplus::Point mPoint = Gdiplus::Point(0, 0);	///< position of this endpoint
};

