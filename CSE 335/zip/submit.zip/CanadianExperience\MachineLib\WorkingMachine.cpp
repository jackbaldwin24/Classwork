/**
 * \file WorkingMachine.cpp
 *
 * \author Jackson Baldwin
 */

#include "pch.h"
#include "WorkingMachine.h"
#include "Component.h"

using namespace Gdiplus;
using namespace std;

/// the framerate the machine plays at
const double FrameRate = 30.0;

/**
 * Draw this machine
 * \param graphics Graphics context to draw in
 * \param location Location of the actual machine
 */
void CWorkingMachine::Draw(Graphics* graphics, Point location)
{
    for (auto component : mComponents)
    {
        component->Draw(graphics, location);
    }
}

/**
 * Add a component to this machine
 * \param component Component to add
 */
void CWorkingMachine::AddComponent(shared_ptr<CComponent> component)
{
	mComponents.push_back(component);
    component->SetMachine(this);
}

/**
 * Converts frame to time and updates the components' time
 * \param frame Frame to convert to time
 */
void CWorkingMachine::FrameToTime(int frame)
{
    for (auto component : mComponents)
    {
        component->SetTime(frame / FrameRate);
    }
}