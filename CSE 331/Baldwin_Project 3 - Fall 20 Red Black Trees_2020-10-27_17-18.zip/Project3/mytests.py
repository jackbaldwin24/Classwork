
from RBtree import RBtree
from RBnode import RBnode


tree = RBtree()
"""
tree.root = RBnode(14, False)
tree.root.left = RBnode(7, False, parent=tree.root)
tree.root.left.left = RBnode(3, True, parent=tree.root.left)
tree.root.left.right = RBnode(10, True, parent=tree.root.left)
tree.root.right = RBnode(21, False, parent=tree.root)
tree.root.right.left = RBnode(17, True, parent=tree.root.right)
tree.root.right.right = RBnode(25, True, parent=tree.root.right)

gen = tree.preorder(tree.root)

print(next(gen, None))
print(next(gen, None))
print(next(gen, None))
print(next(gen, None))
print(next(gen, None))
print(next(gen, None))
print(next(gen, None))
"""

tree.insert(tree.root, 12)
print(tree)
tree.insert(tree.root, 13)
print(tree)
tree.insert(tree.root.right, 11)
print(tree)




