# Name
Jackson Baldwin

# Feedback
I liked it, it was a challenge to think about, but after some thought, I was able to figure out how to iterate through the grid, and iterate through the kxk square at the same time.

# Time to Completion
1.5 hours

# Citations
none