from List import List, fix_playlist

"""
list_2 = List()
list_2.insert(list_2.node.next, 1)
list_2.insert(list_2.node.next, 2)
list_2.insert(list_2.node.next, 2)
list_2.insert(list_2.node.next, 2)
list_2.insert(list_2.node.next, 3)
list_2.insert(list_2.node.next, 3)
list_2.insert(list_2.node.next, 3)
list_2.insert(list_2.node.next, 4)
print(list_2)
"""


lst = List(container=[1, 8, 4, 6, 2, 4, 7])
lyst = List(container=["i", "like", "to", "dance"])

print(lst)
lst.push_front(7)
print(lst)
lst.pop_back()
print(lst)
lst.swap(lyst)
print(lst)
print(lyst)
print(lst.size())
lst.pop_back()
lst.pop_front()
print(lst)
print(lst.size())













