# Name
Jackson Baldwin

# Feedback
This was a very challenging yet fun project. I like how we were given the opportunity to come up
with our own solutions rather than implementing them from pseudocode from lecture/zybooks. I like the way
we were guided to solve the problems. Not too much and not too little guidance.
# Time to Completion
10 hours

# Citations
None