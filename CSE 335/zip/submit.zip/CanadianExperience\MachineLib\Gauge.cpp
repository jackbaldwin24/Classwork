/**
 * \file Gauge.cpp
 *
 * \author Jackson Baldwin
 */

#include "pch.h"
#include "Gauge.h"

using namespace Gdiplus;

 /// Filename for the gauge image
const std::wstring GaugeImageFile = L"images/gauge.png";

/// X Offset of the input from the bottom center of the gauge in pixels
const int OffsetInputY = -6;

/// Y Offset of the input from the bottom center of the gauge in pixels
const int OffsetInputX = 13;

/// X position of the center of the gauge in pixels
const int CenterX = 0;

/// Y position of the center of the gauge in pixels
const int CenterY = -36;

/// How long the needle should be drawn
const int NeedleLength = 10;

/// Minimum rotation angle for the gauge needle in radians
const double MinAngle = 130.0 / 180.0 * M_PI;

/// Maximum rotation angle for the gauge needle in radians
const double MaxRotation = 275.0 / 180.0 * M_PI;

/**
 * Constructor
 */
CGauge::CGauge() : CComponent(), mSink(this)
{
	mImage.SetImage(GaugeImageFile);
	mImage.Rectangle(-mImage.GetImageWidth() / 2, 0);
}

/**
 * Set the pressure of this gauge
 * \param pressure Pressure to set
 */
void CGauge::SetPressure(double pressure)
{
	mSource.SetPressure(pressure);
	mPressure = pressure;
}

/**
 * Draw this gauge
 * \param graphics Graphics context to draw in
 * \param location Location of the machine
 */
void CGauge::Draw(Graphics* graphics, Point location)
{
	mImage.DrawPolygon(graphics, location.X + GetX(), location.Y + GetY());

	Pen needlePen(Color::Red, 2);

	Point center(location.X + GetX() + CenterX, location.Y + GetY()+ CenterY);

	double angle = MinAngle + mPressure * MaxRotation;
	Point value(center.X + NeedleLength * cos(angle), center.Y + NeedleLength * sin(angle));
	graphics->DrawLine(&needlePen, center, value);
}

/**
 * Set the position of this gauge
 * \param x X location
 * \param y Y location
 */
void CGauge::SetPosition(int x, int y)
{
	CComponent::SetPosition(x, y);
	SetSinkPosition();
}

/**
 * Set the position of the air source and air sink
 */
void CGauge::SetSinkPosition()
{
	mSink.SetPosition(GetX() - OffsetInputX, GetY() + OffsetInputY);
	mSource.SetPosition(GetX() + OffsetInputX, GetY() + OffsetInputY);
}
