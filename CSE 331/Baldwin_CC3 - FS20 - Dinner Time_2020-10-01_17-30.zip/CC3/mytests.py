from solution import find_missing_value
sequence = [0, 1, 2, 3]
print(find_missing_value(sequence))