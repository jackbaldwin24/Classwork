# Name
Jackson Baldwin

# Feedback
Was fairly easy, took me a second to realize that I needed to do a binary search,
but after I figured it out it wasn't too bad.

# Time to Completion
2 hours

# Citations
none