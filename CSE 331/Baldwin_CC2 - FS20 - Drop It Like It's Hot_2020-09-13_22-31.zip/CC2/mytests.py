from solution import firefighter

grid = [[]]
k = 2


print(grid[0][0] == null)