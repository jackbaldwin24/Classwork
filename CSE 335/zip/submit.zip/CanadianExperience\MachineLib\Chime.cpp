/**
 * \file Chime.cpp
 *
 * \author Jackson Baldwin
 */

#include "pch.h"
#include "Chime.h"

using namespace Gdiplus;

 /// The chime hammer mount image
const std::wstring ChimeMountImage = L"images/hammer-mount.png";

/// The chime hammer image
const std::wstring ChimeHammerImage = L"images/hammer.png";

/// The chime itself
const std::wstring ChimeImage = L"images/chime.png";

/// Width to draw the actual chime
const int ChimeWidth = 15;

/// Offset of the Chime relative to the origin
/// of this component X value
const double ChimeOffsetX = -18.0;

/// Offset of the Chime Y value
const double ChimeOffsetY = 5.0;

/// The location in the hammer image for the pivot point X
const double HammerPivotX = 33;

/// The location in the hammer image for the pivot point X
const double HammerPivotY = 10;

/// Amount to rotate hammer away from chime in unit rotations
const double HammerRotation = 0.08;

/// Duration for the rocking
const double RockingTime = 2.0;

/// Maximum rocking amount in radians
const double RockAmount = 0.02;

/// How fast we rock in radians per second
const double RockRate = M_PI * 4;

/// Make longer chimes rotate less
const double LengthFactor = 0.00002;

/// Raise the length to this to have a greater effect
const double LengthPower = 2.5;

/**
 * Constructor
 * \param length Length of the chime
 */
CChime::CChime(int length) : CMotionSink()
{
    mMount.SetImage(ChimeMountImage);
    mMount.Rectangle(-mMount.GetImageWidth() / 2, mMount.GetImageHeight());

    mHammer.SetImage(ChimeHammerImage);
    mHammer.Rectangle(-HammerPivotX, HammerPivotY);

    mChime.SetImage(ChimeImage);
    mChime.Rectangle(-ChimeWidth / 2, 0, ChimeWidth, -length);

    mLength = length;
}


/**
 * Draw this chime
 * \param graphics Graphics context to draw in
 * \param location Location of the machine
 */
void CChime::Draw(Graphics* graphics, Point location)
{
    mMount.DrawPolygon(graphics, location.X + GetX(), location.Y + GetY());
    mHammer.SetRotation(HammerRotation - HammerRotation*GetPressure());
    mHammer.DrawPolygon(graphics, location.X + GetX(), location.Y + GetY() + mMount.GetImageHeight() - HammerPivotY);
    if (mRock)
    {
        double time = mTime - mTimeStruck;
        if (time <= 2 && time > 0)
        {
            // some math to determine chime rotation
            double timeInverse = RockingTime - time;
            mChime.SetRotation(1 / (pow(mLength, LengthPower) * LengthFactor) * 
                (timeInverse / RockingTime) * RockAmount * -sin(RockRate * timeInverse));
        }
        else
        {
            mChime.SetRotation(0);
        }

    }

    mChime.DrawPolygon(graphics, location.X + GetX() + ChimeOffsetX, location.Y + GetY() + ChimeOffsetY);
}

/**
 * Set the pressure of this chime
 * \param pressure Pressure to set
 */
void CChime::SetPressure(double pressure)
{
    CMotionSink::SetPressure(pressure);
    if (mRock)
    {
        if (pressure == 1)
        {
            mTimeStruck = mTime;
        }

    }
}