/**
 * \file MovingTubing.h
 *
 * \author Jackson Baldwin
 *
 * Representation of moving tubing
 */

#pragma once
#include "Tubing.h"

 /**
 * Representation of moving tubing
 */
class CMovingTubing :
    public CTubing
{
public:
	/// Constructor
	CMovingTubing() : CTubing() {}

	/// Destructor
	virtual ~CMovingTubing() {}

	/// Copy constructor/disabled
	CMovingTubing(const CMovingTubing&) = delete;

	/// Assignment operator/disabled
	void operator=(const CMovingTubing&) = delete;

	virtual void SetPressure(double pressure) override;
};

