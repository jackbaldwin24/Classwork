/**
 * \file AirSource.cpp
 *
 * \author Jackson Baldwin
 */

#include "pch.h"
#include "AirSource.h"

/**
 * Set the pressure of this air source
 * \param pressure Pressure to set
 */
void CAirSource::SetPressure(double pressure) 
{ 
	if (mAirSink != nullptr)
	{
		mAirSink->SetPressure(pressure);
	}
}