/**
 * \file BigChungusFactory.cpp
 *
 * \author Jackson Baldwin
 */

#include "pch.h"
#include "BigChungusFactory.h"
#include "PolyDrawable.h"
#include "ImageDrawable.h"
#include "HeadTop.h"

using namespace std;
using namespace Gdiplus;

/** This is a concrete factory method that creates our Big Chungus actor.
* \returns Pointer to an actor object.
*/
std::shared_ptr<CActor> CBigChungusFactory::Create()
{
    shared_ptr<CActor> actor = make_shared<CActor>(L"Big Chungus");

    auto body = make_shared<CImageDrawable>(L"Body", L"images/chungus_body.png");
    body->SetCenter(Point(150, 254));
    body->SetPosition(Point(0, -114));
    actor->SetRoot(body);

    auto lleg = make_shared<CImageDrawable>(L"Left Leg", L"images/chungus_lleg.png");
    lleg->SetCenter(Point(134, 73));
    lleg->SetPosition(Point(-12, -20));
    body->AddChild(lleg);

    auto rleg = make_shared<CImageDrawable>(L"Right Leg", L"images/chungus_rleg.png");
    rleg->SetCenter(Point(33, 90));
    rleg->SetPosition(Point(5, -23));
    body->AddChild(rleg);
    
    auto headb = make_shared<CImageDrawable>(L"Head Bottom", L"images/chungus_headb.png");
    headb->SetCenter(Point(87, 89));
    headb->SetPosition(Point(38, -200));
    body->AddChild(headb);

    auto headt = make_shared<CHeadTop>(L"Head Top", L"images/chungus_headt.png");
    headt->SetCenter(Point(191, 233));
    headt->SetPosition(Point(-7, -38));
    headt->SetEyesCenter(Point(190, 205));
    headt->GetLeftEye()->LoadImage(L"images/eye.png");
    headt->GetLeftEye()->SetCenter(Point(10, 11));
    headt->GetRightEye()->LoadImage(L"images/eye.png");
    headt->GetRightEye()->SetCenter(Point(10, 11));
    headb->AddChild(headt);

    auto larm = make_shared<CImageDrawable>(L"Left Arm", L"images/chungus_larm.png");
    larm->SetCenter(Point(89, 24));
    larm->SetPosition(Point(-9, -215));
    body->AddChild(larm);
    
    auto rarm = make_shared<CImageDrawable>(L"Right Arm", L"images/chungus_rarm.png");
    rarm->SetCenter(Point(42, 22));
    rarm->SetPosition(Point(80, -200));
    body->AddChild(rarm);

    auto lhand = make_shared<CImageDrawable>(L"Left Hand", L"images/chungus_lhand.png");
    lhand->SetCenter(Point(56, 21));
    lhand->SetPosition(Point(-65, 66));
    larm->AddChild(lhand);

    auto rhand = make_shared<CImageDrawable>(L"Right Hand", L"images/chungus_rhand.png");
    rhand->SetCenter(Point(65, 31));
    rhand->SetPosition(Point(32, 55));
    rarm->AddChild(rhand);
    

    actor->AddDrawable(body);
    actor->AddDrawable(lleg);
    actor->AddDrawable(rleg);
    actor->AddDrawable(headb);
    actor->AddDrawable(headt);
    actor->AddDrawable(larm);
    actor->AddDrawable(rarm);
    actor->AddDrawable(lhand);
    actor->AddDrawable(rhand);

    return actor;
}
