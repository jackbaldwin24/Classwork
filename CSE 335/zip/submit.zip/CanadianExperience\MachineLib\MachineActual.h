/**
 * \file MachineActual.h
 *
 * \author Jackson Baldwin
 *
 * Our derived Machine class
 */

#pragma once

#include "Machine.h"

class CWorkingMachine;

/**
 * Our derived Machine class
 */
class CMachineActual :
    public CMachine
{
public:
    CMachineActual();

    /// Destructor
    virtual ~CMachineActual() {}

    /// Copy constructor/disabled
    CMachineActual(const CMachineActual&) = delete;

    /// Assignment operator/disabled
    void operator=(const CMachineActual&) = delete;

    
    virtual void SetLocation(int x, int y) override;
    virtual void DrawMachine(Gdiplus::Graphics* graphics) override;
    virtual void SetMachineFrame(int frame) override;
    virtual void SetMachineNumber(int machine) override;
    virtual int GetMachineNumber() override;

    /** Get the location of this machine
    * \returns Point representation of the location */
    Gdiplus::Point GetLocation() { return mLocation; }


private:
    std::shared_ptr<CWorkingMachine> mMachine;              ///< our working machine
    int mMachineNum = 1;                                    ///< number of our machine
    Gdiplus::Point mLocation = Gdiplus::Point(0, 0);        ///< location of our machine
};

