/**
 * \file Drum.cpp
 *
 * \author Jackson Baldwin
 */

#include "pch.h"
#include "Drum.h"

/// Drum image filename
const std::wstring DrumImage = L"images/drum.png";

/**
 * Constructor
 */
CDrum::CDrum() : CMotionSink()
{
	mDrumImage.SetImage(DrumImage);
	mDrumImage.Rectangle(-mDrumImage.GetImageWidth() / 2, 0);
}

/**
 * Draw this drum
 * \param graphics Graphics context to draw in
 * \param location Location of the machine
 */
void CDrum::Draw(Gdiplus::Graphics* graphics, Gdiplus::Point location)
{
	mDrumImage.DrawPolygon(graphics, location.X + GetX(), location.Y + GetY());
}
