/**
 * \file EndPoint.cpp
 *
 * \author Jackson Baldwin
 */

#include "pch.h"
#include "EndPoint.h"
