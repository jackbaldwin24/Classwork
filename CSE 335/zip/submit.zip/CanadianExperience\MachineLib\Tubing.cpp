/**
 * \file Tubing.cpp
 *
 * \author Jackson Baldwin
 */

#include "pch.h"
#include "Tubing.h"

using namespace Gdiplus;
using namespace std;

/**
 * Draw this tubing
 * \param graphics Graphics context to draw in
 * \param location Location of the machine
 */
void CTubing::Draw(Gdiplus::Graphics* graphics, Gdiplus::Point location)
{
	Pen pen(Color::Black, 3);

	CEndPoint* source = mSink.GetSource();  // Where to draw from
	CEndPoint* sink = mSource.GetSink();     // Where to draw to

	CEndPoint* clamp_a = source;
	for (int i = 0; i <= mClamps.size(); ++i)
	{
		// point 1
		Point p1 = Point(clamp_a->GetPosition().X + location.X,
			clamp_a->GetPosition().Y + location.Y);
		
		// rotation and speed for point 2
		double rotation_a = clamp_a->GetRotation();
		int speed_a = clamp_a->GetCurrentSpeed();
		
		//point 2
		Point p2 = Point(p1.X - sin(rotation_a * M_PI * 2) * speed_a,
			p1.Y + cos(rotation_a * M_PI * 2) * speed_a);

		// get the next endpoint
		CEndPoint* clamp_b = sink;
		if (i != mClamps.size()) 
		{ 
			clamp_b = mClamps[i].get();
		}
		
		// point 4
		Point p4 = Point(clamp_b->GetPosition().X + location.X,
			clamp_b->GetPosition().Y + location.Y);

		// rotation and speed for point 3
		double rotation_b = clamp_b->GetRotation();
		int speed_b = clamp_b->GetCurrentSpeed();
		
		// point 3
		Point p3 = Point(p4.X + sin(rotation_b * M_PI * 2) * speed_b,
			p4.Y - cos(rotation_b * M_PI * 2) * speed_b);
		
		auto saveSM = graphics->GetSmoothingMode();
		graphics->SetSmoothingMode(SmoothingMode::SmoothingModeHighQuality);

		// Code to draw the Bezier curve segment
		graphics->DrawBezier(&pen, p1, p2, p3, p4);
		graphics->SetSmoothingMode(saveSM);

		// set the first endpoint for the next iteration to the current last endpoint
		clamp_a = clamp_b;
	}
}

/**
 * Add a clamp to this tubing
 * \param x X location
 * \param y Y locaiton
 * \param rotation Rotation
 * \param speed Speed
 */
void CTubing::AddClamp(int x, int y, double rotation, int speed)
{
	auto clamp = make_shared<Clamp>(x, y, rotation, speed);
	mClamps.push_back(clamp);
}

/**
 * Set the pressure of this tubing
 * \param pressure Pressure to set
 */
void CTubing::SetPressure(double pressure)
{
	mSource.SetPressure(pressure);
}