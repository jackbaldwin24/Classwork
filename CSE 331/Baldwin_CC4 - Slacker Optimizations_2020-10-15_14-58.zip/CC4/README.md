# Name
Jackson Baldwin

# Feedback
This coding challenge was straight forward and not difficult. The hardest part was figuring how to keep track of the shortest book when removing, but it didn't take me too long to realize how to do it.

# Time to Completion
1 hour

# Citations
Onsay's ArrayStack class: https://d2l.msu.edu/d2l/le/content/1193085/viewContent/9253944/View (slide 33)