/**
 * \file AirSink.h
 *
 * \author Jackson Baldwin
 *
 * Representation of an air sink
 */

#pragma once

#include "AirSinkDestination.h"
#include "EndPoint.h"

class CAirSource;

/**
 * Representation of an air sink
 */
class CAirSink : public CEndPoint
{
public:
    CAirSink(IAirSinkDestination* component);

    /// destructor
    virtual ~CAirSink() {}

    /// Copy constructor (disabled)
    CAirSink(const CAirSink&) = delete;

    /// Assignment operator (disabled)
    void operator=(const CAirSink&) = delete;

    void SetPressure(double pressure);
    
    /** Determines if this air source has a component
    * \returns true or false */
    bool IsValid() { return mComponent != nullptr; }

    /** Get the air source of this air sink
    * \returns AirSource associated with this air sink */
    CAirSource* GetSource() { return mSource; }

    /** Set the air source of this air sink
    * \param source AirSource to set */
    void SetSource(CAirSource* source) { mSource = source; }

private:
    IAirSinkDestination* mComponent = nullptr;  ///< the component of this air sink
    CAirSource* mSource;                        ///< the air source of this air sink 
};

