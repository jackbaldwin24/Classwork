/**
 * \file MachineActual.cpp
 *
 * \author Jackson Baldwin
 */

#include "pch.h"
#include "MachineActual.h"
#include "WorkingMachine.h"
#include "MachineOneFactory.h"
#include "MachineTwoFactory.h"

/**
 * Constructor
 */
CMachineActual::CMachineActual()
{
	SetMachineNumber(1);
}

 /**
  * Set the position for the root of the machine
  * \param x X location (pixels)
  * \param y Y location (pixels)
  */
void CMachineActual::SetLocation(int x, int y)
{
	mLocation.X = x;
	mLocation.Y = y;
}

/**
* Draw the machine at the currently specified location
* \param graphics GDI+ Graphics object
*/

void CMachineActual::DrawMachine(Gdiplus::Graphics* graphics)
{
	mMachine->Draw(graphics, mLocation);
}

/**
* Set the current machine animation frame
* \param frame Frame number
*/

void CMachineActual::SetMachineFrame(int frame)
{
	mMachine->FrameToTime(frame);
}
/**
* Set the machine number
* \param machine An integer number. Each number makes a different machine
*/

void CMachineActual::SetMachineNumber(int machine)
{
	if (machine == 1)
	{
		CMachineOneFactory factory;
		mMachine = factory.CreateMachine();
		mMachineNum = machine;
	}
	
	if (machine == 2)
	{
		CMachineTwoFactory factory;
		mMachine = factory.CreateMachine();
		mMachineNum = machine;
	}
}
/**
 * Get the current machine number
 * \return Machine number integer
 */
int CMachineActual::GetMachineNumber()
{
	return mMachineNum;
}