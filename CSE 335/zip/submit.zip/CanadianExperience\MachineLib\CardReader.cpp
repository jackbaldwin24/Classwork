/**
 * \file CardReader.cpp
 *
 * \author Jackson Baldwin
 */

#include "pch.h"
#include "CardReader.h"

using namespace Gdiplus;
using namespace std;

/// Image for the back of the card reader
const std::wstring CardReaderBackImage = L"images/card-reader-back.png";

/// Image for the front of the card reader
const std::wstring CardReaderFrontImage = L"images/card-reader-front.png";


// The card actual dimensions are 847 by 379 pixels,
// a size choosen to make the column spacing exactly
// 10 pixels. We draw it much smaller than that on the screen

/// Width to draw the card on the screen in pixels
const int CardWidth = 132;

/// Height to draw the card on the screen in pixels
const int CardLength = 297;

/// Amount of offset the center of the card so it will
/// appear at the right place relative to the card reader.
const int CardOffsetX = 126;

/// Y dimension of the offset
const int CardOffsetY = 65;

// These values are all for the underlying image. They
// can be used for find the punches.

/// Width of a card column in pixels
const int CardColumnWidth = 10;

/// Height of a card row in pixels
const int CardRowHeight = 29;

/// X offset for the first column (left side)
const int CardColumn0X = 24;

/// Y offset to the first row (0's)
/// There are actually two rows above this that can be used
const int CardRow0Y = 78;

/// Width of a punched hole
const int CardPunchWidth = 8;

/// Height of a punched hole
const int CardPunchHit = 20;

/// Any average luminance below this level is considered a punched hole
const double CardPunchLuminance = 0.1;

//
// These values are for the outputs of the card reader,
// where the tubing attaches.
//

/// Y offset to the first card reader output in pixels
const int OutputOffsetY = -92;

/// X offset to the first card reader output in pixels
const int OutputOffsetX = -35;

/// X spacing for the outputs
const double OutputSpacingX = 10.7;

/// Maximum amount of columns
const int MaxColumns = 80;

/**
 * Constructor
 */
CCardReader::CCardReader() : CComponent()
{
    mBack.SetImage(CardReaderBackImage);
    mBack.Rectangle(-mBack.GetImageWidth() / 2, 0);

    mFront.SetImage(CardReaderFrontImage);
    mFront.Rectangle(-mFront.GetImageWidth() / 2, 0);

    mCard.Rectangle(CardOffsetX, CardOffsetY, CardLength, CardWidth);
    mCard.SetRotation(-0.25);

    // create the air sources for the card
    for (int i = 0; i < CardColumnWidth; ++i)
    {
        auto source = make_shared<CAirSource>();
        mSources.push_back(source);
    }
}

/**
 * Draw the card reader
 * \param graphics Graphics context to draw in
 * \param location Location of the machine
 */
void CCardReader::Draw(Graphics* graphics, Point location)
{
	mBack.DrawPolygon(graphics, location.X + GetX(), location.Y + GetY());
    
    auto cardScale = (double)CardLength / mCard.GetImageWidth();

    mCard.DrawPolygon(graphics, location.X + GetX(), location.Y + GetY() + (mColumn - 1) * cardScale * CardColumnWidth);
	mFront.DrawPolygon(graphics, location.X + GetX(), location.Y + GetY());
}

/**
 * Sets the time of the card reader
 * \param time Time to be set
 */
void CCardReader::SetTime(double time)
{
    // calculate the remainder and current column
    double beat = time * mBeatsPerMinute / 60.0;
    mRemainder = fmod(beat, 1);
    mColumn = (int)beat;

    // set threshold on mColumn
    if (mColumn > MaxColumns)
    {
        mColumn = MaxColumns;
    }

    // Determine what is punched in this row
    for (int row = 0; row < CardColumnWidth; row++)
    {
        if (GetSource(row)->IsValid())
        {
            if (IsPunched(mColumn, row))
            {
                GetSource(row)->SetPressure(1 - mRemainder);
            }
            else
            {
                GetSource(row)->SetPressure(0);
            }
        }

    }
}

/**
 * Determine if a hole is punched in the card.
 * @param column Column on the card, from 0 (left of first column) to 80 (last column)
 * @param row Row on the card, -2 to 9.
 * @return True if hole is punched at column, row
*/
bool CCardReader::IsPunched(int column, int row)
{
    auto luminance = mCard.AverageLuminance(CardColumn0X + (column - 1) * CardColumnWidth,
        CardRow0Y + CardRowHeight * row, CardPunchWidth, CardPunchHit);
    return luminance < CardPunchLuminance;
}

/**
 * Set the position of the card reader in the machine. This
 * must, in turn, set the positions for the sources.
 * @param x X location of the card reader in the machine
 * @param y Y location of the card reader in the machine
*/
void CCardReader::SetPosition(int x, int y)
{
    CComponent::SetPosition(x, y);

    for (int row = 0; row < CardColumnWidth; row++)
    {
        mSources[row]->SetPosition(
            (int)(x + OutputOffsetX + OutputSpacingX * row),
            y + OutputOffsetY
        );
    }
}
