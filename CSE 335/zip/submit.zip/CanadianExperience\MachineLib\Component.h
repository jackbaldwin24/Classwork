/**
 * \file Component.h
 *
 * \author Jackson Baldwin
 *
 * Our base component class
 */

#pragma once

class CWorkingMachine;

/**
 * Our base component class
 */
class CComponent
{
public:
	/// Destructor
	virtual ~CComponent() {}

	/// Copy constructor/disabled
	CComponent(const CComponent&) = delete;

	/// Assignment operator/disabled
	void operator=(const CComponent&) = delete;

	/** Draw this component
	* \param graphics Graphics context to draw in
	* \param location Location of the machine */
	virtual void Draw(Gdiplus::Graphics* graphics, Gdiplus::Point location) = 0;
	
	/** Set the position of this component relative to its machine
	* \param x X location
	* \param y Y location */
	virtual void SetPosition(int x, int y) { mPosition.X = x; mPosition.Y = y; }

	/** Set the current time of this machine 
	* \param time Time to set */
	virtual void SetTime(double time) {}

	/** Get the x location of this component
	* \returns X location */
	int GetX() { return mPosition.X; }
	
	/** Get the y location of this component
	* \returns Y location */
	int GetY() { return mPosition.Y; }

	/** Get this component's machine
	* \returns the compoenent's machine */
	CWorkingMachine* GetMachine() { return mMachine; }

	/** Set this component's machine
	* \param machine Machine to set */
	void SetMachine(CWorkingMachine* machine) { mMachine = machine; }

	
protected:
	/// Constructor
	CComponent() {}
private:
	Gdiplus::Point mPosition = Gdiplus::Point(0, 0);		///< our component's position
	CWorkingMachine* mMachine;								///< the machine of this component
};

