# Name
Jackson Baldwin

# Feedback
This was the hardest coding challenge yet. I was able to get it O(nlogn) early on using two functions,
but then I figured out I can have it all in one function. Lots of time was spent brainstorming and debugging,
but eventually I figured out how to keep track of the values within the recursion. 

# Time to Completion
6 hours

# Citations
none