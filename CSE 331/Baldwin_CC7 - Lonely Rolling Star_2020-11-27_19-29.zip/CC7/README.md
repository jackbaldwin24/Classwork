# **Name**
Jack Baldwin

# **Feedback**
Not bad, getting the sort to work was a little tricky but other than that it wasn't too difficult.
One thing is that the wording and formatting of the description could have been better.
It kept displaying an apostrophe as an i with an accent, as well as other random characters that didn't mean
to be displayed.

# **Time to Complete**
2 hours

#**Citations**
https://stackoverflow.com/questions/7742752/sorting-a-dictionary-by-value-then-by-key