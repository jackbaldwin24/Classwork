/**
 * \file Cylinder.cpp
 *
 * \author Jackson Baldwin
 */

#include "pch.h"
#include "Cylinder.h"

using namespace Gdiplus;

 /// Cylinder base image
const std::wstring CylinderBaseImage = L"images/cylinder-base.png";

/// Cylinder body image
const std::wstring CylinderBodyImage = L"images/cylinder.png";

/// Cylinder ram image
const std::wstring CylinderRamImage = L"images/cylinder-ram.png";

/// The maximum pixels to move the cylinder ram when enabled
const int CylinderMaxExtent = 44;

/// Angle from bottom center of the cylinder
/// to the tubing connector in rotations
const double ConnectorAngle = -0.17;

/// Distance from bottom center of the cylinder to the tubing connector
const double ConnectorDistance = 24.5;

/// Default speed of cylinder endpoint
const int DefaultSpeed = 100;



/**
 * Constructor
 */
CCylinder::CCylinder() : CMotionSource(), mSink(this)
{
    mMount.SetImage(CylinderBaseImage);
    mMount.Rectangle(-mMount.GetImageWidth() / 2, 0);

    mCylinder.SetImage(CylinderBodyImage);
    mCylinder.Rectangle(-mCylinder.GetImageWidth() / 2, 0);

    mRam.SetImage(CylinderRamImage);
    mRam.Rectangle(-mCylinder.GetImageWidth() / 2, 0);
}

/**
 * Draw this cylinder
 * \param graphics Graphics context to draw in
 * \param location Location of the machine
 */
void CCylinder::Draw(Graphics* graphics, Point location)
{
    double extention = mMaxExtent * CylinderMaxExtent * mPressure;
    double xExtention = sin(mRotation * M_PI * 2) * extention;
    double yExtention = -cos(mRotation * M_PI * 2) * extention;
    mMount.DrawPolygon(graphics, location.X + GetX(), location.Y + GetY());
    mRam.DrawPolygon(graphics, location.X + GetX() + xExtention, location.Y + GetY() + yExtention);
    mCylinder.DrawPolygon(graphics, location.X + GetX(), location.Y + GetY());
}

/**
 * Set the pressure of this cylinder
 * \param pressure Pressure to set
 */
void CCylinder::SetPressure(double pressure)
{
    CMotionSource::SetPressure(pressure);
    mPressure = pressure;
}

/**
 * Set the rotation of this cylinder
 * \param rotation Rotation to set
 */
void CCylinder::SetRotation(double rotation)
{
    mMount.SetRotation(rotation);
    mRam.SetRotation(rotation);
    mCylinder.SetRotation(rotation);

    mRotation = rotation;

    // update the cylinder's sink with the new rotation
    SetSinkPosition();
}

/**
 * Set the position of the motion sink
 */
void CCylinder::SetSinkPosition()
{
    mSink.SetPosition(GetX() + cos((ConnectorAngle + mRotation) * M_PI * 2) * ConnectorDistance,
        GetY() + sin((ConnectorAngle + mRotation) * M_PI * 2) * ConnectorDistance);
    mSink.SetRotation(mRotation - 0.5);
    mSink.SetSpeed(DefaultSpeed);
}

/**
 * Set the position of this cylinder relative to its machine
 * \param x X position
 * \param y Y position
 */
void CCylinder::SetPosition(int x, int y)
{
    CComponent::SetPosition(x, y);
    SetSinkPosition();
}
