/**
 * \file MotionSink.cpp
 *
 * \author Jackson Baldwin
 */

#include "pch.h"
#include "MotionSink.h"

/**
 * Set the pressure of this motion sink
 * \param pressure Pressure to set
 */
void CMotionSink::SetPressure(double pressure)
{
    mPressure = pressure;
    if (mChannel != nullptr && pressure == 1)
    {
        mChannel->Play();
    }
}
