/**
 * \file Cymbal.cpp
 *
 * \author Jackson Baldwin
 */

#include "pch.h"
#include "Cymbal.h"

/// Cymbal image filename
const std::wstring CymbalImage = L"images/cymbal-all.png";

/**
 * Constructor
 */
CCymbal::CCymbal() : CMotionSink()
{
	mCymbalImage.SetImage(CymbalImage);
	mCymbalImage.Rectangle(-mCymbalImage.GetImageWidth() / 2, 0);
}

/**
 * Draw this cymbal
 * \param graphics Graphics context to draw in
 * \param location Location of the machine
 */
void CCymbal::Draw(Gdiplus::Graphics* graphics, Gdiplus::Point location)
{
	mCymbalImage.DrawPolygon(graphics, location.X + GetX(), location.Y + GetY());
}