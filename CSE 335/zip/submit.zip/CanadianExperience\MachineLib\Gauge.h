/**
 * \file Gauge.h
 *
 * \author Jackson Baldwin
 *
 * Representation of a gauge
 */

#pragma once

#include "Component.h"
#include "AirSinkDestination.h"
#include "AirSink.h"
#include "AirSource.h"
#include "Polygon.h"

/**
 * Representation of a gauge
 */
class CGauge :
    public CComponent, public IAirSinkDestination
{
public:
	CGauge();

	/// Destructor
	virtual ~CGauge() {}

	/// Copy constructor/disabled
	CGauge(const CGauge&) = delete;

	/// Assignment operator/disabled
	void operator=(const CGauge&) = delete;

	virtual void SetPressure(double pressure) override;
	virtual void SetPosition(int x, int y) override;
	virtual void Draw(Gdiplus::Graphics* graphics, Gdiplus::Point location) override;
	void SetSinkPosition();

	/** Get the air sink of this gauge
	* \returns AirSink of this gauge */
	CAirSink* GetSink() { return &mSink; }

	/** Get the air source of this gauge
	* \returns AirSource of this gauge */
	CAirSource* GetSource() { return &mSource; }

private:
	CAirSource mSource;		///< air source of this gauge
	CAirSink mSink;			///< air sink of this gauge
	CPolygon mImage;		///< Image of this gauge

	double mPressure = 0;	///< current pressure of this gauge
};

