/**
 * \file Cymbal.h
 *
 * \author Jackson Baldwin
 *
 * Representation of a cymbal
 */

#pragma once

#include "MotionSink.h"
#include "Polygon.h"

/**
 * Representation of a cymbal
 */
class CCymbal :
    public CMotionSink
{
public:
	CCymbal();

	/// Destructor
	virtual ~CCymbal() {}

	/// Copy constructor/disabled
	CCymbal(const CCymbal&) = delete;

	/// Assignment operator/disabled
	void operator=(const CCymbal&) = delete;

	virtual void Draw(Gdiplus::Graphics* graphics, Gdiplus::Point location) override;

	

private:
	CPolygon mCymbalImage;		///< Image of the cymbal
};

