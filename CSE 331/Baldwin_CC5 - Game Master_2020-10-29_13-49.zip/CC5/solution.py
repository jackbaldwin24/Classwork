"""
CC5- Trie
Name: Jackson Baldwin
"""

from __future__ import annotations  # allow self-reference


class TreeNode:
    """Tree Node that contains a value as well as left and right pointers"""

    def __init__(self, val: int = 0, left: TreeNode = None, right: TreeNode = None):
        self.val = val
        self.left = left
        self.right = right


def game_master(root: TreeNode) -> int:
    """
    Determines the largest sum of a valid binary search subtree
    :param root: root of the tree to check for valid subtrees
    :return: Int representation of the largest sum of a binary search subtree
    """
    result = 0

    def set_result(value: int):
        """
        Sets a value to be the result if it is larger than the current result
        :param value: value to be set to the result if larger
        """
        nonlocal result
        result = max(result, value)

    def postorder(node: TreeNode):
        """
        Postorder traversal that checks for valid subtrees and keeps
        track of the sum, min, and max of each subtree
        :param node: Current node being analysed
        :return: Tuple containing the sum, min, and max of a subtree rooted at _node_
        """
        if node is not None:

            left_tree = postorder(node.left)
            right_tree = postorder(node.right)

            sum_ = min_ = max_ = 0

            # no children
            if left_tree is None and right_tree is None:
                sum_ = node.val
                min_ = node.val
                max_ = node.val
                set_result(sum_)

            # only right child
            elif left_tree is None:

                if right_tree[0] is not None and node.val < right_tree[1]:
                    # valid subtree
                    sum_ = right_tree[0] + node.val
                    min_ = min(right_tree[1], node.val)
                    max_ = max(right_tree[2], node.val)
                    set_result(sum_)

                else:
                    # not a valid subtree
                    sum_ = None

            # only left child
            elif right_tree is None:
                if left_tree[0] is not None and left_tree[2] < node.val:
                    # valid subtree
                    sum_ = left_tree[0] + node.val
                    min_ = min(left_tree[1], node.val)
                    max_ = max(left_tree[2], node.val)
                    set_result(sum_)
                else:
                    # not a valid subtree
                    sum_ = None

            # two children
            else:
                if left_tree[0] is not None and right_tree[0] is not None and left_tree[2] < node.val < right_tree[1]:
                    # valid subtree
                    sum_ = left_tree[0] + right_tree[0] + node.val
                    min_ = min(left_tree[1], right_tree[1], node.val)
                    max_ = max(left_tree[2], right_tree[2], node.val)
                    set_result(sum_)
                else:
                    # not a valid subtree
                    sum_ = None

            return sum_, min_, max_

    postorder(root)
    return result
