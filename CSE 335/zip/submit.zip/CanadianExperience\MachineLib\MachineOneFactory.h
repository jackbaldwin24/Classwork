/**
 * \file MachineOneFactory.h
 *
 * \author Jackson Baldwin
 *
 * Creates a machine of type 1
 */

#pragma once

#include <memory>
#include "WorkingMachine.h"

/**
 * Creates a machine of type 1
 */
class CMachineOneFactory
{
public:
	CMachineOneFactory() {}

	std::shared_ptr<CWorkingMachine> CreateMachine();

};

