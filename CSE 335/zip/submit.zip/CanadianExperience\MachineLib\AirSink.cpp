/**
 * \file AirSink.cpp
 *
 * \author Jackson Baldwin
 */

#include "pch.h"
#include "AirSink.h"
#include "AirSource.h"

/**
 * Constructor
 * \param component Componet of this air sink
 */
CAirSink::CAirSink(IAirSinkDestination* component) : 
	mComponent(component)
{
}

/**
 * Passes pressure value to the component
 * \param pressure Pressure value to sent to the component
 */
void CAirSink::SetPressure(double pressure)
{
	if (mComponent != nullptr)
	{
		mComponent->SetPressure(pressure);
	}
}
