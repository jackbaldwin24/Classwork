/**
 * \file PictureFactory.cpp
 *
 * \author Charles B. Owen
 */

#include "pch.h"
#include "PictureFactory.h"
#include "HaroldFactory.h"
#include "FlagFactory.h"
#include "BigChungusFactory.h"
#include "ImageDrawable.h"
#include "MachineDrawable.h"

using namespace std;
using namespace Gdiplus;

/**
 * Constructor
*/
CPictureFactory::CPictureFactory()
{
}

/**
 * Destructor
*/
CPictureFactory::~CPictureFactory()
{
}


/** Factory method to create a new picture.
* \returns The created picture
*/
std::shared_ptr<CPicture> CPictureFactory::Create()
{
    shared_ptr<CPicture> picture = make_shared<CPicture>();

    // Create the background and add it
    auto background = make_shared<CActor>(L"Background");
    background->SetClickable(false);
    background->SetPosition(Point(-100, 0));
    auto backgroundI = make_shared<CImageDrawable>(L"Background", L"images/Background.png");
    background->AddDrawable(backgroundI);
    background->SetRoot(backgroundI);
    picture->AddActor(background);

    // Create and add Harold
    CHaroldFactory factory;
    auto harold = factory.Create();

    // This is where Harold will start out.
    harold->SetPosition(Point(750, 500));

    picture->AddActor(harold);

    // Create and add Big Chungus
    CBigChungusFactory cfactory;
    auto chung = cfactory.Create();

    chung->SetPosition(Point(520, 500));
    picture->AddActor(chung);


    // Create and add Flag
    CFlagFactory flagFactory;
    auto flag = flagFactory.Create();

    flag->SetPosition(Point(200, 300));
    picture->AddActor(flag);

    // Create first machine
    auto machineOne = make_shared<CMachineDrawable>(L"1");
    machineOne->SetTimeline(picture->GetTimeline());
    machineOne->SetPosition(200, 300);
    picture->AddMachine(machineOne);
    background->AddDrawable(machineOne);

    // Create second machine
    auto machineTwo = make_shared<CMachineDrawable>(L"2");
    machineTwo->SetTimeline(picture->GetTimeline());
    machineTwo->SetPosition(700, 300);
    picture->AddMachine(machineTwo);
    background->AddDrawable(machineTwo);

    return picture;
}
