/**
 * \file Component.cpp
 *
 * \author Jackson Baldwin
 */

#include "pch.h"
#include "Component.h"
#include "WorkingMachine.h"
