# Name
Jackson Baldwin

# Feedback
I enjoyed it. It was a bit of a challenge since I haven't used Python in awhile, but it was a good refresher. After many attempts, I was able to get it right, but it was not the most efficient route I took. I used two for-loops instead one one, but then I realized I can use one for-loop if I reset the k value back to one, and reset the start and end indexes once I reach a word that isn't in alphabetical order.

# Time to Completion
2 hours to make it work the first time, then 30 minutes to make it work using one for-loop.

# Citations
w3schools.com
tutorialspoint.com
stackoverflow.com