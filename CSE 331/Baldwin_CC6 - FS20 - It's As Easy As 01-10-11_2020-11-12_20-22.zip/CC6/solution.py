"""
CC6 - It's As Easy As 01-10-11
Name: Jackson Baldwin
"""

from typing import Generator, Any


class Node:
    """
    Node Class
    :value: stored value
    :next: reference to next node
    """

    def __init__(self, value) -> None:
        """
        Initializes the Node class
        """
        self.value: str = value
        self.next: Node = None

    def __str__(self) -> str:
        """
        Returns string representation of a Node
        """
        return self.value


class Queue:
    """
    Queue Class
    :first: reference to first node in the queue
    :last: reference to last node in the queue
    """

    def __init__(self) -> None:
        """
        Initializes the Queue class
        """
        self.first: Node = None
        self.last: Node = None

    def __str__(self) -> str:
        """
        String representation of the Queue
        """
        final = "front - "
        current = self.first
        while current is not None:
            final += str(current) + " - "
            current = current.next
        final += "last"
        return final

    def insert(self, value: str) -> None:
        """
        Inserts a string onto the end of the Queue
        :param value: String to be added to the Queue
        """
        new_node = Node(value)
        if self.first is None and self.last is None:
            self.first = self.last = new_node
        else:
            self.last.next = new_node
            self.last = self.last.next

    def pop(self) -> str:
        """
        Returns and removes the first value in the Queue
        :return: First string in the queue
        """
        val = self.first.value
        if self.first is self.last:
            self.first = self.last = None
        else:
            self.first = self.first.next
        return val


def alien_communicator(num: Any) -> Generator[str, None, None]:
    """
    Returns generator object containing string representations
    of binary numbers 0 through n, only if n is an int
    :param num: Any built-in Python type
    :return: If n is an int, generator object containing
        string representations of binary numbers 0-n
    """
    queue = Queue()
    queue.insert("0")

    if not isinstance(num, bool) and isinstance(num, int):
        for num in range(num+1):
            string_1 = queue.pop()
            yield string_1
            if string_1 == "0":
                queue.insert("1")
            else:
                string_2 = string_1
                queue.insert(string_1 + "0")
                queue.insert(string_2 + "1")

