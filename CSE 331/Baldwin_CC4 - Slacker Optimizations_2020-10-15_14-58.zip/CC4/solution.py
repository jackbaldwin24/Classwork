"""
Name: Jackson Baldwin
CC4
CSE 331 Fall 2020
Professor Sebnem Onsay
"""


class Books:

    def __init__(self):
        """
        Initializes a list for the length of the books to be stored in,
        as well as a list to store the length of the shortest books
        """
        self._data = []
        self.shortest_books = [None]

    def insert(self, book):
        """
        Adds a book to the pile while keeping track of the shortest book
        :param book: [Book] book to be added to the pile
        """
        self._data.append(book)
        if self.shortest_books[-1] is None:
            self.shortest_books.pop()
            self.shortest_books.append(book)
        elif book <= self.shortest_books[-1]:
            self.shortest_books.append(book)

    def remove(self):
        """
        Removes the book on the top of the pile while keeping track of the shortest book
        :return: [int] int value representing the length of the book removed
        """
        if self.is_empty():
            return None
        if self._data[-1] == self.shortest_books[-1]:
            self.shortest_books.pop()
            if len(self.shortest_books) == 0:
                self.shortest_books.append(None)
        return self._data.pop()

    def shortest_book(self):
        """
        Returns the shortest book in the pile
        :return: [int] int value representing the length of the shortest book in the pile
        """
        if self.is_empty():
            return None
        return self.shortest_books[-1]

    def __len__(self):
        """
        Determines the length of the pile
        :return: [int] int representing the length of the pile
        """
        return len(self._data)

    def is_empty(self):
        """
        Determines if the pile is empty
        :return: [bool] bool representation of the pile being empty
        """
        return len(self._data) == 0
