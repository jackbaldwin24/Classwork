/**
 * \file AirSinkDestination.h
 *
 * \author Jackson Baldwin
 *
 * Interface representing the component of an air sink
 */

#pragma once

/**
 * Interface representing the component of an air sink
 */
class IAirSinkDestination
{
public:
	/** Set the pressure of this air sink destination
	* \param pressure Pressure to set */
	virtual void SetPressure(double pressure) = 0;
};

