"""
Name: Jack Baldwin
Coding Challenge 7 - Lonely Rolling Star - Solution Code
CSE 331 Fall 2020
Professor Sebnem Onsay
"""
from typing import List, Tuple


class Item:
    """
    A class that will store an item's name and category
    """

    def __init__(self, item_name: str, item_category: str):
        self.name = item_name
        self.category = item_category

    def __repr__(self):
        return "Item('" + self.name + "','" + self.category + "')"

    def get_name(self) -> str:
        """
        returns the strng representing the item's name
        :return: Item name string
        """
        return self.name

    def get_category(self) -> str:
        """
        Returns the string representation of the item's category
        :return: Item category string
        """
        return self.category


class RoboKingOfAllCosmos:
    """
    Stores katamari information
    """

    def __init__(self):
        """
        Creates a new RoboKingOfAllCosmos with empty dicts
        """
        self.items = {}
        self.cat = {}

        # put your scoring container here

    def construct_score_book(self, items_and_size: List[Tuple[str, float]]) -> None:
        """
        Stores a list of items and their size for later use
        :param items_and_size: List of tuples containing the item's name and it's size
        :return: None
        """
        for item in items_and_size:
            self.items[item[0]] = item[1]

    def get_score_book(self) -> List[Tuple[str, float]]:
        """
        Retrieves a list of all the items and their size
        :return: A list of tuples containing the items and their sizes
        """
        result = []
        for name in self.items:
            result.append((name, self.items[name]))
        return result

    def judge_katamari(self, katamari_contents: List[Item]) -> Tuple[float, List[Tuple[str, int]], List[str]]:
        """
        Given a list of items representing the Katamari's contents, evaluate it, give it a
        size based on the items it contains, and find the top 3 categories of items that
        the katamari contains. If a cousin is found in keep track of it.
        :param katamari_contents: List of items representing the Katamari's contents
        :return: A tuple containing the total size, a list containing the top three
        categories and # of occurrences, and a list of all the cousins.
        """
        size = 0
        top_three = []
        cousins = []

        for kat in katamari_contents:
            try:
                size += self.items[kat.name]
            except KeyError:
                size += 0
            try:
                self.cat[kat.category] += 1
            except KeyError:
                self.cat[kat.category] = 1
            if kat.category == "cousins":
                cousins.append(kat.name)

        sorted_ = sorted(self.cat.items(), key=lambda x: (x[1],x[0]), reverse=True)

        i = 0
        for cat in sorted_:
            if i == 3:
                break
            top_three.append((cat[0], cat[1]))
            i += 1

        return round(size, 1), top_three, cousins
