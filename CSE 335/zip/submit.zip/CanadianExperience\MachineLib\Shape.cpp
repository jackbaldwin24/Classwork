/**
 * \file Shape.cpp
 *
 * \author Jackson Baldwin
 */

#include "pch.h"
#include "Shape.h"

using namespace Gdiplus;

/**
 * Draw this shape
 * \param graphics Graphics context to draw in
 * \param location Location of the shape's machine
 */
void CShape::Draw(Graphics* graphics, Point location)
{
	mPolygon.DrawPolygon(graphics, location.X + GetX(), location.Y + GetY());
}
