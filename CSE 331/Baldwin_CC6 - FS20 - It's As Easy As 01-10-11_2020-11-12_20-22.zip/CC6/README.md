# Name
Jackson Baldwin

# Feedback
Hardest part was figuring out the algorithm. Other than that, implementing the Queue class and yielding the results
was fairly simple. The coding standard wouldn't let me use n so I changed it.

# Time to Completion
1.5 hours

# Citations
None