"""
Name: Jackson Baldwin
CC3 - Starter Code
CSE 331 Fall 2020
Professor Sebnem Onsay
"""

from typing import List


def find_missing_value(sequence: List[int]) -> int:
    """
    Given a list of sequential integers starting from 0, find the missing number.

    :param sequence: List[int] a list of n integers in the range of 0 to n
    :return [int] the missing integer in the list
    """
    length = len(sequence)

    def find_missing_value_recursive(start: int, end: int) -> int:
        """
        Given start and end values, determine if the middle element is adjacent to
        a missing number by checking if the next number is not equal to its index.
        If the sum of indexes start and mid is equal to the sum of sequence[start]
        and sequence[mid], then check the right side of the list. If not, check the
        left side.

        :param start: [int] initially 0, will change to mid if the right side of
            the list is being checked
        :param end: [int] initially len(sequence)-1, will change to mid if the
            left side of the list is being checked
        :return: [int] the value that is missing from the list.
        """
        mid = (start + end) // 2

        if sequence[mid] == mid and sequence[mid + 1] != mid + 1:
            return mid + 1
        if mid == 0:
            return 0
        if mid == length - 1:
            return length
        if sequence[start] + sequence[mid] == start + mid:
            return find_missing_value_recursive(mid, end)
        return find_missing_value_recursive(start, mid)

    if length == 0:
        return 0
    if sequence[0] == 0 and sequence[length - 1] == length - 1:
        return length
    return find_missing_value_recursive(0, length - 1)
