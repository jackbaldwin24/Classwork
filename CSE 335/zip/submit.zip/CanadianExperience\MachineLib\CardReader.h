/**
 * \file CardReader.h
 *
 * \author Jackson Baldwin
 *
 * Our card reader
 */

#pragma once

#include "Component.h"
#include "Polygon.h"
#include "AirSource.h"

/**
 * Our card reader
 */
class CCardReader :
    public CComponent
{
public:
    CCardReader();
    
    /// Destructor
    virtual ~CCardReader() {};
    
    /** Copy constructor disabled */
    CCardReader(const CCardReader&) = delete;
    
    /** Assignment operator disabled */
    void operator=(const CCardReader&) = delete;
    
    virtual void Draw(Gdiplus::Graphics* graphics, Gdiplus::Point location) override;
    virtual void SetTime(double time) override;
    virtual void SetPosition(int x, int y) override;
    
    bool IsPunched(int column, int row);

    /** Set the card of this card reader
    * \param filename Image filename of the card to set */
    void SetCard(std::wstring filename) { mCard.SetImage(filename); }

    /**
     * Get an air source.
     * @param i Source index 0-9
     * @return Pointer to CAirSource object.
    */
    std::shared_ptr<CAirSource> GetSource(int i) { return mSources[i]; }

private:
    CPolygon mCard;                 ///< Image of the card
    CPolygon mFront;                ///< Image of the front of the reader
    CPolygon mBack;                 ///< Image of the back of the reader

    int mColumn = 0;                ///< Current column the card is on
    double mBeatsPerMinute = 180;   ///< Beats per minute the reader reads at
    double mRemainder = 0;          ///< Remainder from calculating the beat (used as pressure)

    /// The air sources to drive things
    std::vector<std::shared_ptr<CAirSource>> mSources;
};

