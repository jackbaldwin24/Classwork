/**
 * \file MovingTubing.cpp
 *
 * \author Jackson Baldwin
 */

#include "pch.h"
#include "MovingTubing.h"

/// The factor which we are increasing the speed 
const double TubeSpeedIncrease = 0.25;

/**
 * Set the pressure of this tubing
 * \param pressure Pressure to set
 */
void CMovingTubing::SetPressure(double pressure)
{
	CTubing::SetPressure(pressure);
	
	// update the speed of the clamps
	for (int i = 0; i < GetNumClamps(); ++i)
	{
		auto clamp = GetClamp(i);
		clamp->SetCurrentSpeed(clamp->GetSpeed() + (clamp->GetSpeed() * TubeSpeedIncrease * pressure));
	}
}
