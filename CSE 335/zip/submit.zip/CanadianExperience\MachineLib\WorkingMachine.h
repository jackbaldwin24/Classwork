/**
 * \file WorkingMachine.h
 *
 * \author Jackson Baldwin
 *
 * Our working machine
 */

#pragma once

//#include "WavPlayer.h"
#include <memory>
#include <vector>
#include "WavPlayer.h"
#include "CardReader.h"

/**
 * Our working machine
 */
class CWorkingMachine
{
public:
	/// Constructor
	CWorkingMachine() {}

	/// Destructor
	virtual ~CWorkingMachine() {}

	/// Copy constructor/disabled
	CWorkingMachine(const CWorkingMachine&) = delete;

	/// Assignment operator/disabled
	void operator=(const CWorkingMachine&) = delete;
	
	void Draw(Gdiplus::Graphics* graphics, Gdiplus::Point location);

	void AddComponent(std::shared_ptr<CComponent> component);

	void FrameToTime(int frame);

	/** Get the wav player of this machine
	* \returns Pointer to WavPlayer of this machine */
	CWavPlayer* GetWavPlayer() { return &mMachinePlayer; }

private:
	std::vector<std::shared_ptr<CComponent>> mComponents;		///< the machine's components
	CWavPlayer mMachinePlayer;									///< our wavplayer
};

